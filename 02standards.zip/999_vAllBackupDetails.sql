use master
go
Create or Alter View dbo.vAllBackupDetails
As
WITH    backupsetSummary
          AS ( SELECT   bs.database_name ,
                        bs.type bstype ,
                        backup_finish_date
               FROM     msdb.dbo.backupset bs 
             ),
        MainBigSet
          AS ( SELECT   
                        db.name ,
                        db.state_desc ,
						db.is_read_only,
						db.recovery_model_desc ,
                        bs.type ,
						bs.name BackupuApplication,
						bs.description BackupDescription, 	
						bs.user_name BackupUserName,
                        convert(decimal(10,2),bs.backup_size/1024.00/1024) backup_sizeinMB,
                                    bs.backup_start_date,
                        bs.backup_finish_date,bs.is_copy_only,
						
                                    physical_device_name,
                                    DATEDIFF(MINUTE, bs.backup_start_date, bs.backup_finish_date) AS DurationMins
                              FROM     master.sys.databases db
                        LEFT OUTER JOIN backupsetSummary bss ON bss.database_name = db.name
                        LEFT OUTER JOIN msdb.dbo.backupset bs ON bs.database_name = db.name
                                                              AND bss.bstype = bs.type
                                                              AND bss.backup_finish_date = bs.backup_finish_date
                                    JOIN msdb.dbo.backupmediafamily m ON bs.media_set_id = m.media_set_id
                                    where  db.database_id>4 
             )
SELECT
	@@SERVERNAME SQLServername,
	SERVERPROPERTY('ComputerNamePhysicalNetBIOS') ClusterNodeName,
	db.name DatabaseName,
	(SELECT CONVERT(DECIMAL(10,2),SUM(size)*8.0/1024) AS size FROM sys.master_files WHERE  db.name = DB_NAME(database_id)) AS DBSizeMB,
	db.state_desc,
	db.recovery_model_desc,
	db.is_read_only,
	ao.is_primary_replica,
	BackupType = case when d.type = 'D' then 'Full' when d.type = 'I' then 'Diff' when d.type = 'l' then 'Log' end,
	Backup_start_Date =  d.backup_start_date,
	Backup_end_date =  d.backup_finish_date,
	BackupSize_MB=   d.backup_sizeinMB ,
	BackupDurationSeocnds =  DATEDIFF(SECOND, d.backup_start_date, d.backup_finish_date),
	Backup_path =  d.physical_Device_name,
	Backup_Application =  d.BackupuApplication,
	BackupDescription =  d.BackupDescription,
	BackupUserName = d.BackupUserName,
	BackupIsCopyOnly = d.Is_Copy_Only
FROM
	sys.databases db 
	left join sys.dm_hadr_database_replica_states ao on db.name = db_name(ao.database_id) and is_local = 1
	left join MainBigSet d on db.name = d.name 
where  db.database_id>4 
