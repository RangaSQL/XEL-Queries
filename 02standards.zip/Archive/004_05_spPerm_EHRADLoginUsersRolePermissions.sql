use master
go

Create or Alter procedure dbo.spPerm_EHRADLoginUsersRolePermissions
	@NoExec BIT = 0
as

DECLARE @DatabaseName NVARCHAR(100)   
,@script NVARCHAR(max)
,@User VARCHAR(64)

DECLARE Grant_Permission CURSOR LOCAL FOR
SELECT name FROM sys.databases
WHERE [state_desc]='ONLINE' and  [is_read_only] <> 1 and database_id > 4 and name like 'EMR%'

OPEN Grant_Permission  
FETCH NEXT FROM Grant_Permission INTO @DatabaseName  

WHILE @@FETCH_STATUS = 0  
BEGIN  
	set @script = ''

---------------------------------------------------------------
	--Domain\PSEHRDBReadOnly
---------------------------------------------------------------
		set @user = 'Domain\PSEHRDBReadOnly'
		--create db user if not exists
		SELECT @script = 	'USE '+ '[' + @DatabaseName + '] 	; 
		If Not exists (select * from sys.sysusers where name = '''+@user+''')
			CREATE USER [' + @User + '] FOR LOGIN [' + @User + '];  
		'
		IF @NoExec = 0
			EXEC (@script)
		ELSE
			PRINT @script
	
		--Add to dbreader role if not addede
		SELECT @Script = 'USE '+ '[' + @DatabaseName + '] 	;
		IF IS_ROLEMEMBER (''db_datareader'','''+@user+''') = 0
			EXEC sp_addrolemember N''db_datareader'',N''' + @User + '''; 
		' 
		IF @NoExec = 0
			EXEC (@script)
		ELSE
			PRINT @script


	FETCH NEXT FROM Grant_Permission INTO @DatabaseName  
  
END  
CLOSE Grant_Permission  
DEALLOCATE Grant_Permission

