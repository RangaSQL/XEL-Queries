--This login is the agent service account for PRODBAConfig server and needs to read db inventory.
USE [master]
GO

IF NOT EXISTS (SELECT name FROM sys.server_principals WHERE name = 'NoDomain\SQL-SVC-Agent-PRODBA')
	CREATE LOGIN [NoDomain\SQL-SVC-Agent-PRODBA] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO
IF NOT EXISTS (SELECT name FROM sys.database_principals WHERE name = 'NoDomain\SQL-SVC-Agent-PRODBA')
BEGIN
	CREATE USER [NoDomain\SQL-SVC-Agent-PRODBA] FOR LOGIN [NoDomain\SQL-SVC-Agent-PRODBA]
END
IF IS_ROLEMEMBER ('db_datareader','NoDomain\SQL-SVC-Agent-PRODBA') = 0
BEGIN
	ALTER ROLE db_datareader ADD MEMBER [NoDomain\SQL-SVC-Agent-PRODBA]
END 

