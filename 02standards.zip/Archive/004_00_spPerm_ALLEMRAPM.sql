USE master;
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: Feb 2, 2022
-- Description:	Main Proc that call other Permission SPs. This SP will be used in the single Job to manage permissions for both EMR/APM instances.
-- =============================================
CREATE or ALTER PROCEDURE dbo.spPerm_ALLEMRAPM 
	@NoExec BIT = 0

AS
BEGIN
SET NOCOUNT ON;


--#1 Fix Orphan
Begin Try
	Exec dbo.spPERM_FixDBUsersLogins
	print 'spPERM_FixDBUsersLogins - exec success'
end Try
Begin catch
	print ERROR_MESSAGE()
	raiserror ('Stored Proc: spPERM_FixDBUsersLogins Failed',16,0)

end catch

--#2 spPerm_CreateProsuiteAzure_SSRS_Security_Groups
Begin Try
	Exec dbo.spPerm_CreateProsuiteAzure_SSRS_Security_Groups
	print 'spPerm_CreateProsuiteAzure_SSRS_Security_Groups - exec success'
end Try
Begin catch
	Print ERROR_MESSAGE()
	raiserror ('Stored Proc: spPerm_CreateProsuiteAzure_SSRS_Security_Groups Failed',16,0)
end catch

--#3 spPerm_NoDomain_FMHServices
Begin Try
	Exec dbo.spPerm_NoDomain_FMHServices
	print 'spPerm_NoDomain_FMHServices - exec success'
end Try
Begin catch
	Print ERROR_MESSAGE()
	raiserror ('Stored Proc: spPerm_NoDomain_FMHServices Failed',16,0)
end catch

--#4 spPerm_NoDomain_aceunity
Begin Try
	Exec dbo.spPerm_NoDomain_aceunity
	print 'spPerm_NoDomain_aceunity - exec success'
end Try
Begin catch
	Print ERROR_MESSAGE()
	raiserror ('Stored Proc: spPerm_NoDomain_aceunity Failed',16,0)
end catch

--#5 sp_perm_EHRADLoginUsersRolePermissions
Begin Try
	Exec dbo.spPerm_EHRADLoginUsersRolePermissions
	print 'spPerm_EHRADLoginUsersRolePermissions - exec success'
end Try
Begin catch
	Print ERROR_MESSAGE()
	raiserror ('Stored Proc: sp_perm_EHRADLoginUsersRolePermissions Failed',16,0)
end catch

--#6 sp_Perm_APMADLoginUsersRolePermissions
Begin Try
	Exec dbo.spPerm_APMADLoginUsersRolePermissions
	print 'spPerm_APMADLoginUsersRolePermissions - exec success'
end Try
Begin catch
	Print ERROR_MESSAGE()
	raiserror ('Stored Proc: sp_Perm_APMADLoginUsersRolePermissions Failed',16,0)
end catch

--#7 spPerm_ETL_Reader_EHR
Begin Try
	Exec dbo.spPerm_ETL_Reader_EHR
	print 'spPerm_ETL_Reader_EHR - exec success'
end Try
Begin catch
	Print ERROR_MESSAGE()
	raiserror ('Stored Proc: spPerm_ETL_Reader_EHR Failed',16,0)
end catch

--#8 spPerm_svcsqlagentfqhs00
Begin Try
	Exec dbo.spPerm_svcsqlagentfqhs00
	print 'spPerm_svcsqlagentfqhs00 - exec success'
end Try
Begin catch
	Print ERROR_MESSAGE()
	raiserror ('Stored Proc: spPerm_svcsqlagentfqhs00 Failed',16,0)
end catch

--#8

Print 'All Permissions - exec success!!'

END


