USE master;
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: Sep 27, 2022
-- Description:	Assign db_datareader permissions for svc-sql-agent-fqhs00 for PM database
-- =============================================
Create OR ALTER PROCEDURE dbo.spPerm_svcsqlagentfqhs00
	@NoExec BIT = 0
AS
BEGIN

SET NOCOUNT ON;

DECLARE @script VARCHAR(4000) -- permission script

--create Login if not exsits
if not exists(select * from sys.server_principals where name = 'NoDomain\svc-sql-agent-fqhs00')
begin
	CREATE LOGIN [NoDomain\svc-sql-agent-fqhs00] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english];
end

DECLARE fqhs00 CURSOR FOR 
SELECT script = 'USE [' + name + ']; 
-- Create database user if necessary
IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE name = ''NoDomain\svc-sql-agent-fqhs00'')
begin
	CREATE USER [NoDomain\svc-sql-agent-fqhs00] FOR LOGIN [NoDomain\svc-sql-agent-fqhs00] WITH DEFAULT_SCHEMA=[dbo]
	ALTER ROLE [db_datareader] ADD MEMBER [NoDomain\svc-sql-agent-fqhs00];
end
else
begin
	ALTER ROLE [db_datareader] ADD MEMBER [NoDomain\svc-sql-agent-fqhs00]
	ALTER ROLE [db_executor] ADD MEMBER [NoDomain\svc-sql-agent-fqhs00]
end
-- Grant permissions'
FROM sys.databases
WHERE database_id > 4 
	AND (name LIKE 'Ntier_%' )
	AND (name not LIKE '%Security' )
	AND (name not LIKE '%Training' )
	AND is_read_only = 0 
	AND state_desc = 'ONLINE'
	and @@SERVERNAME not like '%RPT%'

OPEN fqhs00 
FETCH NEXT FROM fqhs00 INTO @script  
WHILE @@FETCH_STATUS = 0  
BEGIN  
	IF @NoExec = 0
		EXEC (@script)
	ELSE
		PRINT @script
	FETCH NEXT FROM fqhs00 INTO @script 
END

CLOSE fqhs00
DEALLOCATE fqhs00


end
go
Exec dbo.spPerm_svcsqlagentfqhs00
