USE master;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: Feb 02, 2020
-- Description:	Grant SSRS security group permissions - For both EMR/APM instances
-- Example: spPerm_CreateProsuiteAzure_SSRS_Security_Groups @NoExec = 0
--Edit history

-- =============================================
CREATE OR ALTER PROCEDURE dbo.spPerm_CreateProsuiteAzure_SSRS_Security_Groups
	@NoExec BIT = 0
AS
BEGIN

SET NOCOUNT ON;

declare @dbname varchar(150)
,@query nvarchar (1000)
,@loginname varchar(100)
,@errormsg VARCHAR(200)
,@login varchar (100)

declare @LoginTable Table(LoginName Varchar(100))
Insert into @LoginTable(LoginName) Values('NoDomain\ReportViewer_'),('NoDomain\ReportWriter_');
--select * from @LoginTable

	Declare logincur cursor for select LoginName from @LoginTable
	open logincur
	fetch next from logincur into @login
	WHILE @@fetch_status = 0
	BEGIN
		DECLARE db CURSOR FOR 
		SELECT NAME FROM sys.databases 
		WHERE (name LIKE 'Ntier%'  OR name LIKE 'EMR%')
			AND name NOT LIKE '%Security'
			AND name NOT LIKE '%Setup'
			AND name NOT LIKE '%Sv1play'
			AND name NOT LIKE '%Test'
			AND state_desc = 'ONLINE'

		OPEN db
		FETCH NEXT FROM db INTO @dbname
		WHILE @@fetch_status = 0
		BEGIN
			SET @loginname = @login+REPLACE(REPLACE(@dbname,'Ntier_',''),'EMR_','')

			--Create Login if not exists
			SET @query = 'IF NOT EXISTS (SELECT name FROM master.dbo.syslogins WHERE name = '''+@loginname+''')
			BEGIN
				CREATE LOGIN ['+@loginname+'] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english];
				ALTER USER ['+@loginname+'] WITH DEFAULT_SCHEMA=[dbo];
				ALTER AUTHORIZATION ON SCHEMA::['+@loginname+'] TO [dbo];
			END'
			IF @NoExec = 0
				Begin Try
					EXEC sp_executesql @query
				end try
				Begin Catch
					set @errormsg = 'Login does not exist in AD: '+@loginname
					Print @errormsg
				end catch
			ELSE 
				PRINT @query

			--Verify CONNECT permission for existing login
			SET @query = 'USE '+ '[' + @dbname + '];
			if exists ( select name from master.dbo.syslogins where name = '''+@loginname+''' )
			begin
				IF NOT EXISTS (SELECT dperm.permission_name FROM sys.database_principals dprinc
				LEFT OUTER JOIN sys.database_permissions dperm ON dprinc.principal_id = dperm.grantee_principal_id
				WHERE dprinc.name = '''+@loginname+''' AND dperm.permission_name = ''CONNECT'')
				BEGIN
					GRANT CONNECT TO ['+@loginname+'];
					ALTER USER ['+@loginname+'] WITH DEFAULT_SCHEMA=[dbo];
					ALTER AUTHORIZATION ON SCHEMA::['+@loginname+'] TO [dbo];
				END
			end	'
			IF @NoExec = 0
				Begin Try
					EXEC sp_executesql @query
				end try
				Begin Catch
					set @errormsg = 'Error granting connect permission: '+@loginname
					Print @errormsg
				end catch
			ELSE 
				PRINT @query
		
			--Create db user and assign permissions
			SELECT @query = 'USE '+ '[' + @dbname + '];
			if exists ( select name from master.dbo.syslogins where name = '''+@loginname+''' )
			begin
				IF NOT EXISTS (SELECT name FROM sys.database_principals WHERE name = '''+@loginname+''')
				BEGIN
					CREATE USER [' + @loginname + '] FOR LOGIN [' + @loginname + '];
				END
				IF IS_ROLEMEMBER (''db_datareader'','''+@loginname+''') = 0
				BEGIN
					ALTER ROLE db_datareader ADD MEMBER [' + @loginname + '];
				END 
				IF IS_ROLEMEMBER (''db_denydatawriter'','''+@loginname+''') = 0
				BEGIN
					ALTER ROLE db_denydatawriter ADD MEMBER [' + @loginname + ']; 
				END
			end	' 
			IF @NoExec = 0
				Begin Try
					EXEC sp_executesql @query
				end try
				Begin Catch
					set @errormsg = 'Error creating db user and granting permissions... '+@loginname
					--Print @errormsg
				end catch
			ELSE 
				PRINT @query

		FETCH NEXT FROM db INTO @dbname
		END
		CLOSE db
		DEALLOCATE db


	FETCH NEXT FROM logincur INTO @login
	END
	CLOSE logincur
	DEALLOCATE logincur
END
GO
