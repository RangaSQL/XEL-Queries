

-- Configure Database mail  
if (select value from sys.configurations where name =  'Database Mail XPs') =  0
begin
	Exec sp_configure 'show advanced options', 1;
	RECONFIGURE;
	exec sp_configure 'Database Mail XPs', 1;
	RECONFIGURE;
end
go

-- 2 changes needed in this script, Change the SMTP Server name

if not exists (select 1 from msdb.dbo.sysmail_account where name = 'Admin' )   
begin
	EXECUTE msdb.dbo.sysmail_add_account_sp
		@account_name = 'Admin',
		@description = 'Profile for sending Health Check Report Emails',
		@email_address = 'HealthChecksProd@Allscripts.com',							-- Change 1, email of the client incharge of ED	
		@display_name = 'ProSuiteHealthCheck-Azure',
		@mailserver_name = 'smtp.sendgrid.net' 	,							-- Change 2, SMTP Server Name
		@port = 25;

	EXECUTE msdb.dbo.sysmail_add_profile_sp
		@profile_name = 'Admin',
		@description = 'Profile for sending Health Check Report Emails' ;

	-- Add the account to the profile
	EXECUTE msdb.dbo.sysmail_add_profileaccount_sp
		@profile_name = 'Admin',
		@account_name = 'Admin',
		@sequence_number =1 ;

	-- Grant access to the profile to the DBMailUsers role
	EXECUTE msdb.dbo.sysmail_add_principalprofile_sp
		@profile_name = 'Admin',
		@principal_name = 'Public',
		@is_default = 1 ;
end
go

--Test Email
Declare @subject varchar(500)
set @subject = cast(@@SERVERNAME as varchar(100))+ ' - SQL Server DBMail setup Success'

EXEC msdb.dbo.sp_send_dbmail
     @profile_name = 'Admin',
     @recipients = 'ranga.narasimhan@allscripts.com;dale.reece@allscripts.com;Rahul.Dinesh@allscripts.com', -- Your email address here!!!
     @body = 'DBMail setup Success',
     @subject = @subject
go

/*

SELECT  
	IsDBMailConfigured = (select value from sys.configurations where name =  'Database Mail XPs')
    ,ProfileName = smp.name  
    ,AccountName = sma.name  
    ,AccountFromAddress = sma.email_address  
    ,AccountReplyTo = sma.replyto_address  
    ,SMTPServer = sms.servername  
    ,SMTPPort = sms.port  
FROM msdb.dbo.sysmail_account sma  
    INNER JOIN msdb.dbo.sysmail_profileaccount smpa ON sma.account_id = smpa.account_id  
    INNER JOIN msdb.dbo.sysmail_profile smp ON smpa.profile_id = smp.profile_id  
    INNER JOIN msdb.dbo.sysmail_server sms ON sma.account_id = sms.account_id;


*/