USE [master]
GO

/*
Since agent acct is different for each capsule, we need a dynamic sql script here

if not exists (select * from sys.server_principals where name = 'IDCPROD\sql_agent_ps')
	CREATE LOGIN [IDCPROD\sql_agent_ps] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO

if (select IS_SRVROLEMEMBER ('sysadmin', 'IDCPROD\sql_agent_ps')) <> 1
	ALTER SERVER ROLE [sysadmin] ADD MEMBER [IDCPROD\sql_agent_ps]
GO

*/
