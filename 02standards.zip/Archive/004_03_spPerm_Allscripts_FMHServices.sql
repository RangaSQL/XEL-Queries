USE master;
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: Feb 2, 2022
-- Description:	Assign database permissions for NoDomain\FMHServices - For both EMR/APM instances
-- Exec dbo.spPerm_NoDomain_FMHServices @Noexec = 1
-- =============================================
CREATE or ALTER PROCEDURE dbo.spPerm_NoDomain_FMHServices 
	@NoExec BIT = 0

AS
BEGIN

SET NOCOUNT ON;
if not exists(select * from sys.server_principals where name = 'NoDomain\FMHServices')
	CREATE LOGIN [NoDomain\FMHServices] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]


DECLARE @script VARCHAR(4000)

DECLARE FMHServices CURSOR FOR 
SELECT script = 'USE ' + [name] + '; 
-- Change schema owner if necessary
IF EXISTS(SELECT [SCHEMA_OWNER] FROM [INFORMATION_SCHEMA].[SCHEMATA] WHERE [SCHEMA_OWNER] = ''NoDomain\FMHServices'' and 
[SCHEMA_NAME]  = ''db_owner'')
	BEGIN
		ALTER AUTHORIZATION ON SCHEMA::[db_owner] TO [db_owner]
	END
-- Correct SID mismatch if necessary
IF EXISTS(SELECT DB_NAME() AS DBName, l.name as SQLServerLogIn, u.name DataBaseID, l.SID as SQLServerSID, u.SID as DatabaseSID 
		FROM sys.syslogins l FULL JOIN sysusers u ON u.sid = l.sid OR l.name = u.name
		WHERE u.name = ''NoDomain\FMHServices'' AND l.sid <> u.sid)
	BEGIN
		DROP USER [NoDomain\FMHServices];
		CREATE USER [NoDomain\FMHServices] FOR LOGIN [NoDomain\FMHServices];
		ALTER USER [NoDomain\FMHServices] WITH DEFAULT_SCHEMA=[dbo];
	END
-- Create executor role if necessary
IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE [name] = ''db_executor'' AND [type]=''R'')
BEGIN
	CREATE ROLE db_executor AUTHORIZATION [db_owner];
	GRANT EXECUTE TO db_executor;
END
-- Create user account if necessary
IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE name = ''NoDomain\FMHServices'')
BEGIN 
	CREATE USER [NoDomain\FMHServices] FOR LOGIN [NoDomain\FMHServices];
	ALTER USER [NoDomain\FMHServices] WITH DEFAULT_SCHEMA=[dbo];
END
-- Grant permissions
IF ''db_datareader'' NOT IN
(SELECT rp.name AS [DB Role] FROM sys.database_role_members drm JOIN sys.database_principals rp ON (drm.role_principal_id = rp.principal_id) JOIN sys.database_principals mp ON (drm.member_principal_id = mp.principal_id) WHERE (mp.name = ''NoDomain\FMHServices''))
ALTER ROLE [db_datareader] ADD MEMBER [NoDomain\FMHServices];
IF ''db_datawriter'' NOT IN
(SELECT rp.name AS [DB Role] FROM sys.database_role_members drm JOIN sys.database_principals rp ON (drm.role_principal_id = rp.principal_id) JOIN sys.database_principals mp ON (drm.member_principal_id = mp.principal_id) WHERE (mp.name = ''NoDomain\FMHServices''))
ALTER ROLE [db_datawriter] ADD MEMBER [NoDomain\FMHServices];
IF ''db_executor'' NOT IN
(SELECT rp.name AS [DB Role] FROM sys.database_role_members drm JOIN sys.database_principals rp ON (drm.role_principal_id = rp.principal_id) JOIN sys.database_principals mp ON (drm.member_principal_id = mp.principal_id) WHERE (mp.name = ''NoDomain\FMHServices''))
ALTER ROLE [db_executor] ADD MEMBER [NoDomain\FMHServices];
IF ''db_owner'' IN
(SELECT rp.name AS [DB Role] FROM sys.database_role_members drm JOIN sys.database_principals rp ON (drm.role_principal_id = rp.principal_id) JOIN sys.database_principals mp ON (drm.member_principal_id = mp.principal_id) WHERE (mp.name = ''NoDomain\FMHServices''))
ALTER ROLE [db_owner] DROP MEMBER [NoDomain\FMHServices];

'
FROM sys.databases
WHERE database_id > 4 
	AND (name LIKE 'Ntier%' OR name LIKE 'EMR_%' OR name = 'Pro_Admin')
	AND name NOT LIKE 'Ntier_%_security%'
	AND name NOT LIKE 'Ntier_security%'
	AND is_read_only = 0 
	AND state_desc = 'ONLINE'

OPEN FMHServices  
FETCH NEXT FROM FMHServices INTO @script  
WHILE @@FETCH_STATUS = 0  
BEGIN 
	IF @NoExec = 0
		EXEC (@script)
	ELSE
		PRINT @script
	FETCH NEXT FROM FMHServices INTO @script 
END

CLOSE FMHServices 
DEALLOCATE FMHServices

--ADD IMO DB access to [NoDomain\FMHServices]
if exists(select name from master.sys.databases where name = 'IMO')
begin
		set  @script = 'use [IMO];
		IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE name = ''NoDomain\FMHServices'')
		BEGIN
			USE [master]
			ALTER DATABASE [IMO] SET  READ_WRITE WITH NO_WAIT

			use [IMO];
			CREATE USER [NoDomain\FMHServices] FOR LOGIN [NoDomain\FMHServices];
			ALTER ROLE [db_datareader] ADD MEMBER [NoDomain\FMHServices];

			USE [master];
			ALTER DATABASE [IMO] SET  READ_ONLY WITH NO_WAIT
		END
		if IS_ROLEMEMBER (''db_datareader'',''NoDomain\FMHServices'') = 0
		begin
			USE [master]
			ALTER DATABASE [IMO] SET  READ_WRITE WITH NO_WAIT
	
			use [IMO];
				EXEC sp_addrolemember N''db_datareader'', N''NoDomain\FMHServices''

			USE [master];
			ALTER DATABASE [IMO] SET  READ_ONLY WITH NO_WAIT
		end
		'
		IF @NoExec = 0
		begin
			EXEC (@script)
			print 'Permissions granted to IMO DB for [NoDomain\FMHServices]'
		end
		ELSE
			PRINT @script
end

--ADD Medispan DB access to [NoDomain\FMHServices]
if exists(select name from master.sys.databases where name = 'Medispan')
begin
		set  @script = 'use [Medispan];
		IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE name = ''NoDomain\FMHServices'')
		BEGIN
			USE [master]
			ALTER DATABASE [Medispan] SET  READ_WRITE WITH NO_WAIT

			use [Medispan];
			CREATE USER [NoDomain\FMHServices] FOR LOGIN [NoDomain\FMHServices];
			ALTER ROLE [db_datareader] ADD MEMBER [NoDomain\FMHServices];

			USE [master];
			ALTER DATABASE [Medispan] SET  READ_ONLY WITH NO_WAIT
		END
		if IS_ROLEMEMBER (''db_datareader'',''NoDomain\FMHServices'') = 0
		begin
			USE [master]
			ALTER DATABASE [Medispan] SET  READ_WRITE WITH NO_WAIT
	
			use [Medispan];
				EXEC sp_addrolemember N''db_datareader'', N''NoDomain\FMHServices''

			USE [master];
			ALTER DATABASE [Medispan] SET  READ_ONLY WITH NO_WAIT
		end
		'
		IF @NoExec = 0
		begin
			EXEC (@script)
			print 'Permissions granted to Medispan DB for [NoDomain\FMHServices]'
		end
		ELSE
			PRINT @script
end
end
