USE master;
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: Feb 02, 2022
-- Description:	Assign database permissions for NoDomain\aceunity - For both EMR/APM instances
-- =============================================
CREATE OR ALTER PROCEDURE DBO.spPerm_NoDomain_aceunity
	@NoExec BIT = 0

AS
BEGIN

SET NOCOUNT ON;

DECLARE @script NVARCHAR(4000) -- permission script

DECLARE aceunity CURSOR FOR 
SELECT script = 'USE [' + name + ']; 
-- Change schema owner if necessary
IF EXISTS(SELECT [SCHEMA_NAME] FROM [INFORMATION_SCHEMA].[SCHEMATA] WHERE [SCHEMA_NAME] LIKE ''NoDomain\aceunity'')
	BEGIN
		ALTER AUTHORIZATION ON SCHEMA::[NoDomain\aceunity] TO dbo;
	END
-- Correct SID mismatch if necessary
IF EXISTS(SELECT DB_NAME() AS DBName, l.name as SQLServerLogIn, u.name DataBaseID, l.SID as SQLServerSID, u.SID as DatabaseSID 
		FROM sys.syslogins l FULL JOIN sysusers u ON u.sid = l.sid OR l.name = u.name
		WHERE u.name = ''NoDomain\aceunity'' AND l.sid <> u.sid)
	BEGIN
		DROP USER [NoDomain\aceunity];
		CREATE USER [NoDomain\aceunity] FOR LOGIN [NoDomain\aceunity];
		ALTER USER [NoDomain\aceunity] WITH DEFAULT_SCHEMA=[dbo];
	END
-- Create user account if necessary
IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE name = ''NoDomain\aceunity'')
	BEGIN 
		CREATE USER [NoDomain\aceunity] FOR LOGIN [NoDomain\aceunity];
		ALTER USER [NoDomain\aceunity] WITH DEFAULT_SCHEMA=[dbo]
	END;
-- Create executor role if necessary
IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE [name] = ''db_executor'' AND [type]=''R'')
	BEGIN
		CREATE ROLE db_executor AUTHORIZATION [db_owner];
		GRANT EXECUTE TO db_executor;
	END
-- Grant permissions
ALTER ROLE [db_owner] ADD MEMBER [NoDomain\aceunity];

'
FROM sys.databases
WHERE (name LIKE 'EMR_%' OR name LIKE 'Ntier_%' OR name = 'EMR')
	AND name NOT IN('') -- Databases to be excluded
	AND is_read_only = 0 
	AND state_desc = 'ONLINE'

OPEN aceunity  
FETCH NEXT FROM aceunity INTO @script  
WHILE @@FETCH_STATUS = 0  
BEGIN  
	IF @NoExec = 0
		EXEC (@script)
	IF @NoExec = 1
		PRINT @script
	FETCH NEXT FROM aceunity INTO @script 
END

CLOSE aceunity 
DEALLOCATE aceunity

END
