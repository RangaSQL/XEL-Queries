USE [master]
GO


--NoDomain\svcProSOne
if not exists(select * from sys.server_principals where name = 'NoDomain\svcProSOne')
begin
	CREATE LOGIN [NoDomain\svcProSOne] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english];
	ALTER SERVER ROLE [sysadmin] ADD MEMBER [NoDomain\svcProSOne]
end
GO
if not (IS_SRVROLEMEMBER ('sysadmin','NoDomain\svcProSOne') = 1)
	ALTER SERVER ROLE [sysadmin] ADD MEMBER [NoDomain\svcProSOne]

--NoDomain\ProSuiteSQlAdmin
if not exists(select * from sys.server_principals where name = 'NoDomain\ProSuiteSQlAdmin')
begin
	CREATE LOGIN [NoDomain\ProSuiteSQlAdmin] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english];
	ALTER SERVER ROLE [sysadmin] ADD MEMBER [NoDomain\ProSuiteSQlAdmin]
end
GO
if not (IS_SRVROLEMEMBER ('sysadmin','NoDomain\ProSuiteSQlAdmin') = 1)
	ALTER SERVER ROLE [sysadmin] ADD MEMBER [NoDomain\ProSuiteSQlAdmin]

	
