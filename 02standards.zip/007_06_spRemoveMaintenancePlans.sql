USE master;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: 02222022 
-- Description:	This SP removes unwanted maintenance plans
--Example: Exec dbo.spRemoveMaintenancePlanJobs 


Create OR ALTER PROCEDURE dbo.spRemoveMaintenancePlan
@NoExec BIT = 0
AS
BEGIN
declare @folder_id uniqueidentifier
declare @plan_id uniqueidentifier
declare @plan_name nvarchar (100)

declare MaintPlancursor cursor for
select name as PlanName
from msdb.dbo.sysmaintplan_plans
where name in('Allscripts PM Database Backups and Maintenance',
'System DB Backups',
'Allscripts EHR Database Backups and Maintenance'
)

open MaintPlancursor 
fetch next from MaintPlancursor into @plan_name
while @@FETCH_STATUS = 0
begin
	if @NoExec = 0
	begin
		begin try
			select  @plan_id = id from msdb.dbo.sysmaintplan_plans where [name] = @plan_name
			select @folder_id = folderid from msdb.dbo.sysssispackages where name = @plan_name

			exec msdb.[dbo].sp_ssis_deletepackage @plan_name,@folder_id
			exec msdb.[dbo].[sp_maintplan_delete_plan] @plan_id
		end try
		begin catch
			print error_message()
			print @plan_name
		end catch
	end
	fetch next from MaintPlancursor into @plan_name
end
close MaintPlancursor
deallocate MaintPlancursor
end
