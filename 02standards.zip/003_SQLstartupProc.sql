use master
go

Create or Alter Procedure dbo.SQLStartProcSP
As
Begin
		--DBCC TRACEON (1117, -1)	-- When a file in the filegroup meets the autogrow threshold, all files in the filegroup grow
		--DBCC TRACEON (1118, -1)	-- Removes most single page allocations on the server, reducing contention on the SGAM page
		--DBCC TRACEON (4199, -1)	-- Enables query optimizer (QO) changes released in SQL Server Cumulative Updates and Service Packs.
		--DBCC TRACEON (3226, -1)	-- suppress successful backup SQLlog entries
		--DBCC TRACEON (2371, -1)	-- update stats for large tables
		--DBCC TRACEON(3023, -1) -- Enable Backup checksum
	IF (SELECT SERVERPROPERTY ('IsHadrEnabled')) = 1 --For Always On
	Begin
		DBCC TRACEON (9567, -1)	-- enable compression of the data stream during automatic seeding
	End

	--disable Other Unwanted TraceFlage
	DBCC TRACEOFF (174,4199,1117,3023,3226,2371,1118, -1);
End
go

exec sp_procoption @ProcName = [SQLStartProcSP], 
@OptionName = 'STARTUP', 
@OptionValue = [on]




if not exists (SELECT [name] FROM sysobjects WHERE type = 'P'  AND OBJECTPROPERTY(id, 'ExecIsStartUp') = 1)
	print 'Startup Proc Not Set'

--restart and check below command

--DBCC TRACESTATUS(-1);�
