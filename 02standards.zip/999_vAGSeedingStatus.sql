use master
go
Create or Alter View dbo.vAGSeedingStatus
as
SELECT local_database_name
 ,role_desc
 ,internal_state_desc
 ,transfer_rate_bytes_per_second
 ,(((transfer_rate_bytes_per_second)/1024/1024)) transfer_rate_MB_per_second
 ,(((transferred_size_bytes)/1024/1024)) transfered_Size_MB
 ,(((database_size_bytes)/1024/1024)) database_size_MB
 ,cast(((transferred_size_bytes*1.0/database_size_bytes*1.0)*100) as numeric(5,2))  As PercentTransfered
 ,start_time_utc
 ,end_time_utc
 ,estimate_time_complete_utc
 ,total_disk_io_wait_time_ms
 ,total_network_wait_time_ms
 ,is_compression_enabled
FROM sys.dm_hadr_physical_seeding_stats
