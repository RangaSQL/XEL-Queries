﻿
#If you have just one server EHR/APM server just comment the block 32-34 or 37-39

#################################

#Change SQL Instance Name - Rename the instance back to "A00EHR1-DBSS101" after execution
$EHRServer = "APS017D-DBRPTe.allscripts.pro"

#Change SQL Instance Name - Rename the instance back to "A00APM1-DBSS101" after execution
#$APMServer = "APS017D-DBEHR.allscripts.pro"

#################################


IF (!(Get-Module -Name sqlps))
    {
        Write-Host 'Loading SQLPS Module' -ForegroundColor DarkYellow
        Push-Location
        Import-Module sqlps -DisableNameChecking
        Pop-Location
    }
  
  
$localScriptRoot = "C:\Temp\SQLStandardization\02 - Standards - Powershell"

$scripts = Get-ChildItem $localScriptRoot | Where-Object {$_.Extension -eq ".sql"}
  
foreach ($s in $scripts)
    {
        #EHR

        Write-Host "Running Script on $EHRserver : " $s.Name -BackgroundColor DarkGreen -ForegroundColor White
        $script = $s.FullName
        Invoke-Sqlcmd -ServerInstance $EHRServer -InputFile $script -DisableVariables #-TrustServerCertificate

    }
 