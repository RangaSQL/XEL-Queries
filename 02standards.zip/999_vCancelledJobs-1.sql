Create or alter View dbo.vCancelledJobs
As
SELECT @@servername SQLInstance,
		j.Name
			,CONVERT(DATETIME, RTRIM(run_date))
			+ ((run_time / 10000 * 3600)
			+ ((run_time % 10000) / 100 * 60)
			+ (run_time % 10000) % 100) / (86399.9964) AS run_datetime
			, run_duration, step_name, message
		FROM
			msdb.dbo.sysjobhistory sjh join msdb.dbo.sysjobs j on sjh.job_id = j.Job_id
		WHERE
		1 = 1
		 and step_name = '(Job outcome)'
		 and message like 'The job was stopped %'
/*
--Query to get summary view
select @@servername Servername,name Jobname, max(run_datetime) lastRun, max(run_duration) RunDurationmax, min(run_duration) MinRunDuration from vCancelledJobs group by name
*/
		