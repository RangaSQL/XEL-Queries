Create or alter view.dbo.vDAGStatus
as
Select 
local_database_name
 ,role_desc
 ,internal_state_desc
 ,total_disk_io_wait_time_ms
 ,total_network_wait_time_ms
  ,transfer_rate_MB_per_second
  ,database_size_MB
  ,transfered_Size_MB
  ,remaining_size_to_transfer_MB
  ,PercentTransfered
,MinutesToTransfer
,HoursToTransfer
,CONVERT(datetime, SWITCHOFFSET(CONVERT(DATETIMEOFFSET, start_time_utc), DATENAME(TZOFFSET, SYSDATETIMEOFFSET()))) AS start_time
,dateadd(mi,MinutesToTransfer,getdate()) estimated_end_time
,getdate() as current_datetime
,cast((datediff(hh,(CONVERT(datetime, SWITCHOFFSET(CONVERT(DATETIMEOFFSET, start_time_utc), DATENAME(TZOFFSET, SYSDATETIMEOFFSET())))),getdate())) as int) elapsed_hours
from
(SELECT local_database_name
 ,role_desc
 ,internal_state_desc
 ,transfer_rate_bytes_per_second
 ,(((transfer_rate_bytes_per_second)/1024/1024)) transfer_rate_MB_per_second
 ,(((transferred_size_bytes)/1024/1024)) transfered_Size_MB
 ,(((database_size_bytes)/1024/1024)) database_size_MB
 ,(((database_size_bytes-transferred_size_bytes)/1024)/1024) remaining_size_to_transfer_MB
 ,(((((database_size_bytes-transferred_size_bytes)/1024)/1024)/15)/60) MinutesToTransfer
 ,((((((database_size_bytes-transferred_size_bytes)/1024)/1024)/15)/60)/60) HoursToTransfer
 ,cast(((transferred_size_bytes*1.0/database_size_bytes*1.0)*100) as numeric(5,2))  As PercentTransfered
 ,start_time_utc
 ,end_time_utc
 ,estimate_time_complete_utc
 ,total_disk_io_wait_time_ms
 ,total_network_wait_time_ms
 ,is_compression_enabled
FROM sys.dm_hadr_physical_seeding_stats)x



