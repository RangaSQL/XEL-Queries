Create Or Alter View dbo.vFailedJobs
As
Select @@servername SQLInstance, lf.JobName,jj.enabled, ls.LastsuccessDate, lf.LastFailedDate,
	 (select count(*) From msdb.dbo.sysjobhistory jh  
		where jj.job_id = jh.job_id  and jh.step_id = 0 
		--and (msdb.dbo.agent_datetime(jh.run_date, jh.run_time) > isnull((ls.LastsuccessDate),'01-01-1900'))) FailureCount,
		and jh.message like 'The job failed%'
		) FailureCount,
	LastStatus = case when lf.LastFailedDate > ls.LastsuccessDate then 'Failed'
						when lf.LastFailedDate < ls.LastsuccessDate then 'Success'
						when ls.LastsuccessDate is null then 'Failed' end
from
	(Select x.Name JobName, Max(run_datetime) LastFailedDate
	from
		(SELECT
		j.Name
			,CONVERT(DATETIME, RTRIM(run_date))
			+ ((run_time / 10000 * 3600)
			+ ((run_time % 10000) / 100 * 60)
			+ (run_time % 10000) % 100) / (86399.9964) AS run_datetime
			, run_duration, step_name, message
		FROM
			msdb.dbo.sysjobhistory sjh join msdb.dbo.sysjobs j on sjh.job_id = j.Job_id
		WHERE
		1 = 1
		 and step_name = '(Job outcome)'
		 and message like 'The job Failed.%'
			)x group by x.name
		)lf
left join
	(Select x.Name JobName, Max(isnull(run_datetime, '01-01-1900')) LastsuccessDate
	from
		(SELECT
			j.Name
				,CONVERT(DATETIME, RTRIM(run_date))
				+ ((run_time / 10000 * 3600)
				+ ((run_time % 10000) / 100 * 60)
				+ (run_time % 10000) % 100) / (86399.9964) AS run_datetime
				, run_duration, step_name, message
			FROM
				msdb.dbo.sysjobhistory sjh join msdb.dbo.sysjobs j on sjh.job_id = j.Job_id
			WHERE
			1 = 1
			 and step_name = '(Job outcome)'
			 and (message like 'The job Succeeded.%' or message like 'The job was stopped prior to completion%')
			)x group by x.name
	)ls 
	on lf.JobName = ls.JobName --and lf.LastFailedDate > ls.LastsuccessDate
	join msdb.dbo.sysjobs jj on lf.JobName = jj.name
go
--select * from dbo.vFailedJobs


 