USE master;
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: Feb 10, 2022
-- Description:	Fix DB user in each database 
-- =============================================
Create OR ALTER PROCEDURE dbo.spPERM_FixDBUsersLogins
	@NoExec BIT = 0

AS
BEGIN

SET NOCOUNT ON;

DECLARE @script NVARCHAR(4000) -- permission script
,@dbname varchar(50)
,@login varchar(50)

--we don't want to fix all users, just the ones in use, we can add as needed.
declare @LoginTable Table(LoginName Varchar(100))
Insert into @LoginTable(LoginName) 
Values('ETL_Reader');	--remove the semicolon if you need to add more logins, just the last one should have semicolon
--,('Other');

Declare logincur cursor for select LoginName from @LoginTable
	open logincur
	fetch next from logincur into @login
	WHILE @@fetch_status = 0
	BEGIN
		DECLARE db CURSOR FOR 
		SELECT NAME FROM sys.databases 
		WHERE (name LIKE 'Ntier%'  OR name LIKE 'EMR%' or name ='IMO' or name ='Medispan')
			AND name NOT LIKE '%Security'
			AND name NOT LIKE '%Setup'
			AND name NOT LIKE '%Sv1play'
			AND name NOT LIKE '%Test'
			AND state_desc = 'ONLINE'

		OPEN db
		FETCH NEXT FROM db INTO @dbname
		WHILE @@fetch_status = 0
		BEGIN
		--for Medispan and IMO, fix only between 11 pm and 6 am
		if ((@dbname = 'Medispan' or @dbname = 'IMO') and (datepart(HH,getdate()) < 6))
		begin
			--verify if it is a orphan user
			SET @script = 'USE '+ '[' + @dbname + '];
						IF EXISTS(
						SELECT A.name
						FROM sys.database_principals a
						Left Join Master.[sys].[syslogins] b
						on a.name = b.name
						where (a.sid <> b.sid ) and type = '''+'S'+''' AND principal_id > 4 
						and a.name = +'''+@login+'''
						)
						Begin
							ALTER DATABASE ['+@dbname+'] SET  READ_WRITE WITH NO_WAIT;
							ALTER DATABASE ['+@dbname+'] SET  single_user with rollback immediate;
							ALTER USER ['+@login+'] WITH LOGIN = ['+@login+'];
							ALTER DATABASE ['+@dbname+'] SET  READ_ONLY WITH NO_WAIT;
							ALTER DATABASE ['+@dbname+'] SET  multi_user ;
						end'
			IF @NoExec = 0
				EXEC sp_executesql @script
			ELSE 
				PRINT @script
		END
		ELSE
		if ((@dbname <> 'Medispan' AND @dbname <> 'IMO'))
		BEGIN
			--verify if it is a orphan user
			SET @script = 'USE '+ '[' + @dbname + '];
						IF EXISTS(
						SELECT A.name
						FROM sys.database_principals a
						Left Join Master.[sys].[syslogins] b
						on a.name = b.name
						where (a.sid <> b.sid ) and type = '''+'S'+''' AND principal_id > 4 
						and a.name = +'''+@login+'''
						)
						ALTER USER '+@login+' WITH LOGIN='+@login				
			IF @NoExec = 0
				EXEC sp_executesql @script
			ELSE 
				PRINT @script
		END
		FETCH NEXT FROM db INTO @dbname
		END
		CLOSE db
		DEALLOCATE db

	FETCH NEXT FROM logincur INTO @login
	END
	CLOSE logincur
	DEALLOCATE logincur
END
GO

