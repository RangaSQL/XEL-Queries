/*
Read Error Logs for the Keyword given and number of days to go back:

The below example returns all log entries with word "non-yielding" during the last 3 days. 

If the optional parameter @Lastcount 2 is added , returns just the last 2 occurrences
Example: 
Exec master.dbo.usp_ReadErroLogHistoryByKeyword @keyword = 'login failed', @DaysToBoback = 1--, @Lastcount = 1000
Exec master.dbo.usp_ReadErroLogHistoryByKeyword @keyword = 'first four bytes', @DaysToBoback = 10, @Lastcount = 10
*/
use master 
go
if object_id('dbo.usp_ReadErroLogHistoryByKeyword') is not null
	drop proc dbo.usp_ReadErroLogHistoryByKeyword
go
Create procedure dbo.usp_ReadErroLogHistoryByKeyword
@keyword varchar(100),
@DaysToBoback tinyint,
@Lastcount int = 0
As


if object_id('tempdb..#ErrorLogDetails') is not null
	drop table #ErrorLogDetails
if object_id('tempdb..#Errorlogs') is not null
	drop table #Errorlogs

Declare @oldDate date, @quote char(1)
set @oldDate = dateadd(DD,(@DaysToBoback*-1),Getdate())			
set @quote = char(39)

Create Table #ErrorLogDetails(LogDate Datetime, Process varchar(256), LogMessage varchar(8000))

CREATE TABLE #Errorlogs
(
    log_number INT,
    log_date DATE,
    log_size INT
);
INSERT #Errorlogs ( log_number, log_date, log_size )
EXEC ( 'EXEC sys.sp_enumerrorlogs;' );
--select * from #Errorlogs

declare     @log_number INT,     @log_date DATE, @strsql nvarchar(200)

declare readerror cursor for select log_number,log_date from #Errorlogs order by log_date desc
open readerror
fetch next from readerror into @log_number, @log_date
while @@fetch_status = 0
begin
	if @log_date < @OldDate
		break
	set @strsql = 'sp_readerrorlog '+cast(@log_number as varchar)+', 1,'+ @quote+@keyword+@quote
	insert into #ErrorLogDetails execute(@strsql)
	fetch next from readerror into @log_number, @log_date
end
close readerror
deallocate readerror

Delete from  #ErrorLogDetails where LogDate < @oldDate

if @Lastcount = 0
select  distinct @@Servername SQLServerName,LogDate, Process, LogMessage from #ErrorLogDetails order by Logdate Desc
else
begin
	set @strsql = 'select  top '+cast(@Lastcount as varchar)+ ' @@Servername SQLServerName,LogDate, Process, LogMessage from #ErrorLogDetails order by Logdate Desc'
	exec (@strsql)
end

