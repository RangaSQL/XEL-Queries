Create or Alter view dbo.vDatabaseFilesSize
As
SELECT   'DatabaseName' = DB_NAME(database_id)
,'FileName' = NAME
,FILE_ID
,physical_name
,'SizeKB' = CONVERT(BIGINT, size) * 8 
,'SizeMB' = (CONVERT(BIGINT, size) * 8 )/1024
,max_size
,'MaxSizeKB' = (
CASE max_size
WHEN -1
THEN  0
ELSE CONVERT(BIGINT, max_size) * 8
END
)
,'GrowthPercent' =  CASE is_percent_growth WHEN 1 THEN  growth else null end
,'GrowthSize_KB' = CASE is_percent_growth WHEN 0 then CONVERT(BIGINT, growth)  else null end
,'GrowthSize_MB' = CASE is_percent_growth WHEN 0 then (CONVERT(BIGINT, growth) * 8)/1024 else null end
,'type_desc' = type_desc
--into DatabaseFileGrowthInfo
FROM sys.master_files
--where database_id = 2
where database_id > 4
