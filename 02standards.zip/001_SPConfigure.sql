/*

Can be run for a Whole cluster from CMS Registered Server List

*/

sp_configure 'show advanced options', 1;
GO
RECONFIGURE;
GO
exec sp_configure 'remote admin connections', 1
GO
exec sp_configure 'Database Mail XPs', 1;
GO
DBCC TRACEOFF (4199,1117,3023,3226,2371,1118, -1);
go
USE [master]
GO
EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'NumErrorLogs', REG_DWORD, 15
GO
RECONFIGURE
GO
EXEC sys.sp_configure N'show advanced options', N'1'  RECONFIGURE WITH OVERRIDE
GO
if (@@SERVERNAME like '%EHR%')
begin
	EXEC sys.sp_configure N'cost threshold for parallelism', N'250'
	EXEC sys.sp_configure N'max degree of parallelism', N'4'
end
go
if (@@SERVERNAME like '%APM%')
begin
	EXEC sys.sp_configure N'cost threshold for parallelism', N'350'
	EXEC sys.sp_configure N'max degree of parallelism', N'2'
end
go
EXEC sys.sp_configure N'optimize for ad hoc workloads', N'1'
GO
EXEC sys.sp_configure N'backup compression default', N'1'
GO
EXEC sys.sp_configure N'Agent XPs', N'1'
GO

USE [master]
GO
EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultData', REG_SZ, N'M:\Data'
GO
EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultLog', REG_SZ, N'L:\Log'
GO

RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'show advanced options', N'0'  RECONFIGURE WITH OVERRIDE
GO

--Model DB Auto Grow:
USE [master]
GO
ALTER DATABASE [model] MODIFY FILE ( NAME = N'modeldev', FILEGROWTH = 256MB )
GO
ALTER DATABASE [model] MODIFY FILE ( NAME = N'modellog', FILEGROWTH = 256MB )
GO
--MAster DB Auto Grow:
USE [master]
GO
ALTER DATABASE [master] MODIFY FILE ( NAME = N'master', FILEGROWTH = 256MB )
GO
ALTER DATABASE [master] MODIFY FILE ( NAME = N'mastlog', FILEGROWTH = 256MB )
GO
--MSDB DB Auto Grow:
USE [master]
GO
ALTER DATABASE [MSDB] MODIFY FILE ( NAME = N'msdbdata', FILEGROWTH = 256MB )
GO
ALTER DATABASE [msdb] MODIFY FILE ( NAME = N'msdblog', FILEGROWTH = 256MB )
GO

USE [msdb]
GO
EXEC msdb.dbo.sp_set_sqlagent_properties @jobhistory_max_rows=100800, @jobhistory_max_rows_per_job=100
GO
USE [master]
GO
ALTER DATABASE [model] SET RECOVERY SIMPLE WITH NO_WAIT
GO