use master;
go
Create or Alter proc dbo.spAlterDBAutoGrowSetting
@NoExec BIT = 0
As
/*-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: Feb 02, 2022
-- Description:	Alter DB file auto grow if it is in Percent or less than 128 MB
				***	Must have the view: vDatabaseFilesSize	***
				\\aceeallscripts.file.core.windows.net\dba\AAA - SQL Standards\Azure Setup\02 - Standards - Powershell\019_vDatabaseFilesSize
-- =============================================
DB File Auto Grow Settings:
File size < 5 GB, autoGrowth 128 MB
File size > 5 GB and < 10 GB, autoGrowth 256 MB
File size > 10 GB and < 50 GB, autoGrowth 512 MB
File size > 50 GB, autoGrowth 1024 MB
*/
declare @strsql nvarchar(500)
,@dbName varchar(100)
,@filename varchar(100)
,@growsizemb varchar(10)
,@filesize int

declare dbfiles_cursor cursor for 
select DatabaseName, [Filename] , dbs.SizeMB--,dbs.GrowthSize_MB,dbs.GrowthPercent
from dbo.vDatabaseFilesSize dbs join sys.databases sdb on dbs.DatabaseName = sdb.name
where sdb.state_desc = 'online' and sdb.is_read_only = 0 and sdb.database_id > 4
and ((
dbs.SizeMB < 5126 and dbs.GrowthSize_MB <> 128 
OR
dbs.SizeMB > 5126 and dbs.SizeMB < 1024 and dbs.GrowthSize_MB <> 256 
OR
dbs.SizeMB > 10240 and dbs.SizeMB < 51200 and dbs.GrowthSize_MB <> 512 
OR
dbs.SizeMB > 51200 and dbs.GrowthSize_MB <> 1024
)
OR
(dbs.GrowthPercent is not null)
)

open dbfiles_cursor

fetch next from dbfiles_cursor into @dbname, @filename, @filesize
while @@FETCH_STATUS = 0


begin
	set @growsizemb = '128MB'

	IF @filesize < 5126							--5 GB
		set @growsizemb ='128MB' 
	else if (@filesize > 5126 and @filesize < 10240) --5-10 GB
		set @growsizemb ='256MB' 
	else if (@filesize > 10240 and @filesize < 51200) --10 - 50 GB
		set @growsizemb ='512MB' 
	else if @filesize > 51200						-- > 50 GB 
		set @growsizemb ='1024MB' 

	set @strsql = 'ALTER DATABASE ['+@DBName+'] MODIFY FILE ( NAME = N'''+@filename+''', FILEGROWTH = '+@growsizemb+' )'
	if @NoExec = 0
	begin
		begin try
			exec sp_executesql @strsql
		end try
		begin catch
			print error_message()
			print @strsql
		end catch
	end
	else
		print @strsql

	fetch next from dbfiles_cursor into @dbname, @filename,@filesize
end

close dbfiles_cursor
deallocate dbfiles_cursor
go