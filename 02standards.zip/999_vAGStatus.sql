Create or Alter View dbo.vAGStatus 
As
/*
Created By: Ranga Narasimhan
Created Date: 06-16-2023
*/
Select distinct Ag.AGName, ag.availability_mode_desc, ag.failover_mode_desc, ag.primary_recovery_health_desc, ag.synchronization_health_desc, Prisec.PrimaryReplicaName, prisec.SecondaryReplicaName,  PriSec.AGDBName, Prisec.PrimarySyncStatus, PriSec.SecondarySyncStatus
from 
(SELECT distinct
Groups.name as AGName,
secondary_role_allow_connections_desc AS ReadableSecondary,
Replicas.[availability_mode_desc] ,
Replicas.failover_mode_desc,
states.primary_recovery_health_desc,
states.synchronization_health_desc
FROM master.sys.availability_groups Groups
INNER JOIN master.sys.availability_replicas Replicas ON Groups.group_id = Replicas.group_id
INNER JOIN master.sys.dm_hadr_availability_group_states States ON Groups.group_id = States.group_id
)AG
join
(
Select pri.ag_name AGName,pri.PrimaryReplicaName, sec.SecondaryReplicaName, pri.ag_db_name AGDBName, pri.synchronization_state_desc PrimarySyncStatus, sec.synchronization_state_desc SecondarySyncStatus
From
(select ag_name, replica_name as PrimaryReplicaName, ag_db_name, synchronization_state_desc
from master.sys.dm_hadr_cached_database_replica_states where is_primary_replica = 1)Pri 
inner join (select ag_name, replica_name as SecondaryReplicaName, ag_db_name, synchronization_state_desc
from master.sys.dm_hadr_cached_database_replica_states where is_primary_replica = 0)sec on pri.ag_name = sec.ag_name and pri.ag_db_name = sec.ag_db_name
)PriSec
on AG.AGName = PriSec.AGName
go
--select * from dbo.AGStatus
