-- =============================================
-- Author:      Eli Leiba- Create date: 01-04-2021
-- Description: Check current SQL memory status compared to the OS status
-- =============================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE or Alter FUNCTION dbo.fn_CheckSQLMemory()
RETURNS @Sql_MemStatus TABLE 
 (
   SQLServer_Start_DateTime datetime, 
   SQL_current_Memory_usage_mb int,
   SQL_Max_Memory_target_mb int,
   SQL_Configured_Max_Memory int,
   OS_Total_Memory_mb int,
   OS_Available_Memory_mb int
   --,OS_AvailableMemoryPercent As  cast ( (((OS_Available_Memory_mb-SQL_Max_Memory_target_mb)*1.0/OS_Total_Memory_mb*1.0)*100.0) as int)
   )
AS
BEGIN
   declare @strtSQL datetime
   declare @currmem int
   declare @smaxtarmem int
   declare @SQLMaxMemory int
   declare @osmaxmm int
   declare @osavlmm int 
 
   -- SQL memory
   SELECT 
      @strtSQL = sqlserver_start_time,
      @currmem = (committed_kb/1024),
      @smaxtarmem = (committed_target_kb/1024)           
   FROM sys.dm_os_sys_info;
   
   SELECT @SQLMaxMemory = CAST((CONVERT(INT,value_in_use)) AS INT) FROM sys.configurations where name = 'max server memory (MB)'

   --OS memory
   SELECT 
      @osmaxmm = (total_physical_memory_kb/1024),
      @osavlmm = (available_physical_memory_kb/1024) 
   FROM sys.dm_os_sys_memory;
   
   INSERT INTO @Sql_MemStatus values (@strtSQL, @currmem, @smaxtarmem,@SQLMaxMemory, @osmaxmm, @osavlmm)
 
   RETURN 
END
GO 
USE master 
GO 
--select * from dbo.fn_CheckSQLMemory()
GO 
Create Or Alter View dbo.vCheckSQLmemory
As
select @@servername ServerName,*,cast((((SQL_Configured_Max_Memory * 1.0)/(OS_Total_Memory_mb * 1.0))*100.00) as numeric(4,2))  PercentOfOSMemory from dbo.fn_CheckSQLMemory()
go
--select *  from vCheckSQLmemory
