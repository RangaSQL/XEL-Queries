--Jobs run by the hour
Create or Alter view dbo.vJobRunInfo
As
Select distinct JobName,RunDateTime,RunHour, RunDurationSeconds,RunDurationMinutes 
from
(
select 
 j.name as 'JobName',
 run_date,
 run_time,
 DATEPART(HH,(msdb.dbo.agent_datetime(run_date, run_time))) RunHour,
 msdb.dbo.agent_datetime(run_date, run_time) as 'RunDateTime',
 run_duration,
 (run_duration/10000*3600 + (run_duration/100)%100*60 + run_duration%100 + 31 ) 
          as 'RunDurationSeconds',
 ((run_duration/10000*3600 + (run_duration/100)%100*60 + run_duration%100 + 31 ) / 60) 
          as 'RunDurationMinutes'
From msdb.dbo.sysjobs j 
INNER JOIN msdb.dbo.sysjobhistory h 
 ON j.job_id = h.job_id 
where j.enabled = 1  --Only Enabled Jobs
and h.step_id = 0
)x 
where RunDateTime > getdate()-30
go