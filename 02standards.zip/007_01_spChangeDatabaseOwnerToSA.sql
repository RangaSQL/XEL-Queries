USE master;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: 02222022 
-- Description:	This SP changes the DB owner to SA
--Example: Exec dbo.spChangeDatabaseOwnerToSA 
-- =============================================
Create OR ALTER PROCEDURE dbo.spChangeDatabaseOwnerToSA
@NoExec BIT = 0
AS
BEGIN
declare @strsql nvarchar(4000)
declare db_cursor cursor for
select 
--SUSER_SNAME(owner_sid),
(case when state_desc = 'ONLINE' then 'ALTER AUTHORIZATION on DATABASE::['+name+'] to [SA];' else '-- Turn On ' end) as CommandToRun
from master.sys.databases where SUSER_SNAME(owner_sid) <> 'sa' and is_read_only = 0
and database_id > 4

open db_cursor 
fetch next from db_cursor into @strsql
while @@FETCH_STATUS = 0
begin
	if @NoExec = 0
	begin
		begin try
			exec sp_executesql @strsql
		end try
		begin catch
			print error_message()
			print @strsql
		end catch
	end
	else
		print @strsql

	fetch next from db_cursor into @strsql
end
close db_cursor
deallocate db_cursor
end
