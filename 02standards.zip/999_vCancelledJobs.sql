SELECT distinct @@servername Servername, 
    j.name AS job_name, ri.RunDateTime, ri.RunHour, ri.RunDurationMinutes
FROM msdb.dbo.sysjobhistory jh 
JOIN msdb.dbo.sysjobs j ON jh.job_id = j.job_id
JOIN msdb.dbo.sysjobsteps js
    ON j.job_id = js.job_id
inner join dbo.vJobRunInfo ri on j.name = ri.JobName
WHERE
 last_run_outcome = 3 
AND msdb.dbo.agent_datetime(run_date, run_time) > '05-01-2024'
