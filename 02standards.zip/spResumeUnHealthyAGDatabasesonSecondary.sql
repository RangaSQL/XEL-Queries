Create Or Alter Procedure dbo.spResumeUnHealthyAGDatabasesonSecondary
As
DECLARE @ServerName VARCHAR(128) = (SELECT @@SERVERNAME),@ReplicaRole VARCHAR(15)
Declare @stmt nvarchar(500)
SELECT @ReplicaRole = (SELECT role_desc
FROM sys.dm_hadr_availability_replica_states st
	INNER JOIN sys.availability_replicas rep ON rep.replica_id = st.replica_id
WHERE rep.replica_server_name = @ServerName)
IF @ReplicaRole = 'Secondary'
BEGIN
	declare dbcursor cursor for select 'ALTER DATABASE '+db_name(database_id)+' SET HADR RESUME;' stmt  from sys.dm_hadr_database_replica_states where synchronization_health_desc = 'Not_Healthy' for read only
	open dbcursor
	fetch next from dbcursor into @stmt
	while @@fetch_status = 0
	begin
		print @stmt
		Exec sp_executesql @stmt
		fetch next from dbcursor into @stmt
	end
	close dbcursor
	deallocate dbcursor
END
WAITFOR DELAY '00:00:10'
