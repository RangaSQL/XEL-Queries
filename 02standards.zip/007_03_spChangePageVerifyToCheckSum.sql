USE master;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: 02222022 
-- Description:	This SP changes the DB owner to SA
--Example: Exec dbo.spChangePageVerifyToCheckSum 
-- =============================================
Create OR ALTER PROCEDURE dbo.spChangePageVerifyToCheckSum
@NoExec BIT = 0
AS
BEGIN
declare @strsql nvarchar(4000)
declare checksum_cursor cursor for
SELECT 'ALTER DATABASE [' + name + '] SET PAGE_VERIFY CHECKSUM WITH NO_WAIT;' AS [DBChecksum] 
FROM SYS.DATABASES WHERE STATE_DESC ='ONLINE'and is_read_only <> 1 AND page_verify_option_desc != 'CHECKSUM';
open checksum_cursor 
fetch next from checksum_cursor into @strsql
while @@FETCH_STATUS = 0
begin
	if @NoExec = 0
	begin
		begin try
			exec sp_executesql @strsql
		end try
		begin catch
			print error_message()
			print @strsql
		end catch
	end
	else
		print @strsql

	fetch next from checksum_cursor into @strsql
end
close checksum_cursor
deallocate checksum_cursor
end
