USE [master]
GO

/****** Object:  StoredProcedure [dbo].[spRemoveOtherMaintenanceJobs]    Script Date: 3/18/2022 2:00:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: 02222022 
-- Description:	This SP disables Maintenance jobs that does not have DB Maintain
--Example: Exec dbo.spRemoveOtherMaintenanceJobs 


Create or Alter  PROCEDURE [dbo].[spRemoveOtherMaintenanceJobs]
@NoExec BIT = 0
AS
BEGIN
	if exists (select * from msdb.dbo.sysjobs where name = 'IndexOptimize - USER_DATABASES')
		EXEC msdb.dbo.sp_update_job @job_name=N'IndexOptimize - USER_DATABASES',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'DatabaseBackup - USER_DATABASES - FULL')
		EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseBackup - USER_DATABASES - FULL',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'DatabaseBackup - USER_DATABASES - DIFF')
		EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseBackup - USER_DATABASES - DIFF',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'DatabaseBackup - USER_DATABASES - LOG')
		EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseBackup - USER_DATABASES - LOG',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'DatabaseBackup - SYSTEM_DATABASES - FULL')
		EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseBackup - SYSTEM_DATABASES - FULL',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'DatabaseIntegrityCheck - SYSTEM_DATABASES')
		EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseIntegrityCheck - SYSTEM_DATABASES',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'DatabaseIntegrityCheck - USER_DATABASES')
		EXEC msdb.dbo.sp_update_job @job_name=N'DatabaseIntegrityCheck - USER_DATABASES',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'Allscripts EHR Database Backups and Maintenance.DB Backup')
		EXEC msdb.dbo.sp_update_job @job_name=N'Allscripts EHR Database Backups and Maintenance.DB Backup',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'Allscripts EHR Database Backups and Maintenance.DBCC and Update Stats')
		EXEC msdb.dbo.sp_update_job @job_name=N'Allscripts EHR Database Backups and Maintenance.DBCC and Update Stats',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'Allscripts EHR Database Backups and Maintenance.TL Backup')
		EXEC msdb.dbo.sp_update_job @job_name=N'Allscripts EHR Database Backups and Maintenance.TL Backup',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'Maintenance - MDRX_CHAT - Backup Database')
		EXEC msdb.dbo.sp_update_job @job_name=N'Maintenance - MDRX_CHAT - Backup Database',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'Maintenance - PRO_ADMIN - Backup Database')
		EXEC msdb.dbo.sp_update_job @job_name=N'Maintenance - PRO_ADMIN - Backup Database',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'Allscripts PM Database Backups and Maintenance.PM Database Optimization')
		EXEC msdb.dbo.sp_update_job @job_name=N'Allscripts PM Database Backups and Maintenance.PM Database Optimization',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'Allscripts PM Database Backups and Maintenance.PM DB Backups')
		EXEC msdb.dbo.sp_update_job @job_name=N'Allscripts PM Database Backups and Maintenance.PM DB Backups',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'Allscripts PM Database Backups and Maintenance.PM DB Integrity Checks')
		EXEC msdb.dbo.sp_update_job @job_name=N'Allscripts PM Database Backups and Maintenance.PM DB Integrity Checks',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'Allscripts PM Database Backups and Maintenance.PM TL Backups')
		EXEC msdb.dbo.sp_update_job @job_name=N'Allscripts PM Database Backups and Maintenance.PM TL Backups',  @enabled=0

	if exists (select * from msdb.dbo.sysjobs where name = 'System DB Backups.Backup')
		EXEC msdb.dbo.sp_update_job @job_name=N'System DB Backups.Backup',  @enabled=0

	--Other EMR jobs to be disabled
	declare @Jobname varchar(200)
	declare jobcursor cursor for
	select name from msdb.dbo.sysjobs 
	where name like 'Maintenance - EMR_%'
	and (	name like '%Backup Primary Filegroup Only'
		 or	name like '%DBCC Check Primary Filegroup Only'
		 or	name like '%Defrag - Create List'
		 or	name like '%Defrag - Process List'
		 or	name like '%Update Stats'
		)
		and enabled = 1
	open jobcursor
	fetch next from jobcursor into @jobname
	while @@fetch_status = 0
	begin
	if exists (select * from msdb.dbo.sysjobs where name = @Jobname)
		EXEC msdb.dbo.sp_update_job @job_name=@Jobname, @enabled=0
		fetch next from jobcursor into @jobname
	end
	close jobcursor
	deallocate jobcursor
end
GO


