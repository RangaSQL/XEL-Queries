use master
go

Create Or Alter Procedure dbo.spStopJobIfNotAGPrimary
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: Jan 01, 2024
-- Description:	This SP will be executed on the first step in all Jobs, If the job runs on a AG secondary, this job will stop the job and quit. The job will be cancelled instead of failed.
-- =============================================

As
DECLARE @ServerName VARCHAR(128) = (SELECT @@SERVERNAME)
,@ReplicaRole VARCHAR(15)
,@Jobname sysname
,@Jobid uniqueidentifier

SELECT @jobname=b.name,@jobid=b.job_id  
FROM sys.dm_exec_sessions a,msdb.dbo.sysjobs b
WHERE a.session_id=@@spid
AND 
(SUBSTRING(MASTER.dbo.FN_VARBINTOHEXSTR(CONVERT(VARBINARY(16), b.JOB_ID)),1,10)) = SUBSTRING(a.PROGRAM_NAME,30,10)

SELECT @ReplicaRole = (SELECT role_desc
FROM sys.dm_hadr_availability_replica_states st
	INNER JOIN sys.availability_replicas rep ON rep.replica_id = st.replica_id
WHERE rep.replica_server_name = @ServerName)

IF @ReplicaRole = 'SECONDARY'
BEGIN
	EXEC msdb.dbo.sp_stop_job @job_name = @Jobname
END
ELSE
	SELECT @ReplicaRole
go