use master
go
Create OR Alter proc dbo.spRecompileSlowSPsForAnInstance
@dbname varchar(100) = null
,@avgReads int = 1000000	-- 1 million reads
,@avgdurationinseconds tinyint = 3	--duration greater than 3 seconds
,@avgcpu int = 10000
/*
--Ideally Run for a particular DB, if there is a instance wide slowness , don't provide dbname parameter
--Criteria where (avg_reads > 1000000 OR avg_elapsed_time_ms > 3000) --more than 2 second
Exec dbo.spRecompileSlowSPsForAnInstance @dbname = 'EMR_70354'

With Reads and duration Parameters;
Exec dbo.spRecompileSlowSPsForAnInstance @dbname = 'EMR_70354', @avgreads = 5000000, @avgdurationseconds = 5

Exec dbo.spRecompileSlowSPsForAnInstance 
*/
As
set nocount on
declare @query nvarchar (2000)
    set nocount on

    drop table if exists #SlowSP
	CREATE TABLE #SlowSP(
		[DBName] varchar(50) Not Null,
		[SchemaName] varchar(50) Not Null,
		[SPName] [sysname] NOT NULL,
		[execution_count] [bigint] NOT NULL,
		[total_logical_reads] [bigint] NOT NULL,
		[total_elapsed_time] [bigint] NOT NULL,
		[total_worker_time] [bigint] NOT NULL,
		[avg_elapsed_time_ms] [bigint] NULL,
		[avg_reads] [bigint] NULL,
		[avg_cpu] [bigint] NOT NULL,
	)
    set @query='USE [?]
    IF (''?'' like ''Ntier%'' or ''?'' like ''EMR%'' )
    BEGIN 
		insert into #SlowSP
		select DB_Name() DBName,* from 
		(select top 10 schema_name(so.schema_id) SchemaName, so.name, st.execution_count, st.total_logical_reads, st.total_elapsed_time, st.total_worker_time, ((st.total_elapsed_time/st.execution_count)/1000) avg_elapsed_time_ms, (st.total_logical_reads/st.execution_count) avg_reads, (st.total_worker_time/st.execution_count) avg_cpu
		from sys.dm_exec_procedure_stats st join sys.objects so on st.object_id = so.object_id
		where last_execution_time > dateadd(HH,-2,getdate())
		)x 
		order by avg_reads desc 
    end'

	EXEC master..sp_MSForeachdb @query

--select * from #slowsp 
--where (avg_reads > @avgReads OR avg_elapsed_time_ms > @avgdurationinseconds Or avg_cpu > @avgcpu) 
--order by avg_reads desc

--select top 10 'exec (''use '+dbname+'; exec sp_recompile ['+SchemaName+'.'+SPname+']'')' from #SlowSP
--where (@dbname is null or dbname = @dbname)
--order by avg_reads desc

select top 10 * from #slowsp order by avg_reads desc

Declare recompilesp cursor for select top 10 'use '+dbname+'; exec sp_recompile ['+SchemaName+'.'+SPname+']' sqltext from #SlowSP
where (@dbname is null or dbname = @dbname)
order by avg_reads desc
open recompilesp
fetch next from recompilesp into @query
while @@fetch_status = 0
begin
	print @query
	--exec sp_executesql @query
	fetch next from recompilesp into @query
end
close recompilesp
deallocate recompilesp
go
Exec dbo.spRecompileSlowSPsForAnInstance