USE [master]
GO

/****** Object:  StoredProcedure [dbo].[CheckJobstatus]    Script Date: 2/12/2021 10:23:19 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER Procedure [dbo].[CheckJobstatus]
@JobName varchar(500)
,@status varchar(10) output
--exec dbo.CheckJobstatus @JobName = 'TestJob'
--exec dbo.CheckJobstatus @JobName = 'AAA - Involta Migration DatabaseBackup -  FULL'
As
declare @intJobStatus smallint
,@JobStatus varchar(20)
,@Message varchar(500)
if exists(SELECT sj.name
  FROM msdb..sysjobactivity aj
  JOIN msdb..sysjobs sj
    on sj.job_id = aj.job_id
 WHERE aj.stop_execution_date  IS NULL     -- job hasn't stopped running
   AND aj.start_execution_date IS NOT NULL -- job is currently running
   AND sj.name = @JobName
   AND NOT EXISTS( -- make sure this is the most recent run
                   select 1
                     from msdb..sysjobactivity new
                    where new.job_id = aj.job_id
                      and new.start_execution_date > aj.start_execution_date))
	set @intJobStatus = 1	--job is executing
else
	set @intJobStatus = 0	--job is finished

select @status = Case when @intJobStatus = 1 then 'Executing' when @intJobStatus = 0 then 'Finished'  end


GO


