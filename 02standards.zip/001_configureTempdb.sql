If exists (select * from  sys.master_files mf where database_id =2 and ((size*8)/1024)/1024 <> 1024 )
begin
	declare @strsql nvarchar(200)
	,@filename varchar(100)
	declare tsize_cursor cursor for select name from  sys.master_files mf where database_id =2 and (((size*8)/1024)/1024 <> 1024)
	open tsize_cursor
	fetch next from tsize_cursor into @filename
	while @@FETCH_STATUS = 0
	begin
		set @strsql = 'ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'''+@filename+''', SIZE = 10GB , FILEGROWTH = 1GB )'
		--print @strsql
		exec (@strsql)
		fetch next from tsize_cursor into @filename
	end
	close tsize_cursor
	deallocate tsize_cursor
end
