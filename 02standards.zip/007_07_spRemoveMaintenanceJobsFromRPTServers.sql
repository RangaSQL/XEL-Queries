USE [master]
GO

/****** Object:  StoredProcedure [dbo].[spRemoveMaintenanceJobsFromRPTServers]    Script Date: 3/18/2022 2:00:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: 10312022 
-- Description:	This SP deletes DB Maintain jobs from RPT servers
--Example: Exec dbo.spRemoveMaintenanceJobsFromRPTServers 


Create or Alter  PROCEDURE [dbo].[spRemoveMaintenanceJobsFromRPTServers]
@NoExec BIT = 0
AS
IF @@SERVERNAME like '%RPT%'
Begin
	if exists (select * from msdb.dbo.sysjobs where name = 'DB Maintain - DatabaseIntegrityCheck - USER_DATABASES')
		EXEC msdb.dbo.sp_delete_job @job_name=N'DB Maintain - DatabaseIntegrityCheck - USER_DATABASES'

	if exists (select * from msdb.dbo.sysjobs where name = 'DB Maintain - DBCC CheckDB - USER_DATABASES')
		EXEC msdb.dbo.sp_delete_job @job_name=N'DB Maintain - DBCC CheckDB - USER_DATABASES'

	if exists (select * from msdb.dbo.sysjobs where name = 'DB Maintain - GrantPermissions EMR APM')
		EXEC msdb.dbo.sp_delete_job @job_name=N'DB Maintain - GrantPermissions EMR APM'

	if exists (select * from msdb.dbo.sysjobs where name = 'DB Maintain - Index Rebuild - USER_DATABASES')
		EXEC msdb.dbo.sp_delete_job @job_name=N'DB Maintain - Index Rebuild - USER_DATABASES'

	if exists (select * from msdb.dbo.sysjobs where name = 'DB Maintain - Other Miscellaneous Maintenance')
		EXEC msdb.dbo.sp_delete_job @job_name=N'DB Maintain - Other Miscellaneous Maintenance'

	if exists (select * from msdb.dbo.sysjobs where name = 'DB Maintain - Update Statistics - USER_DATABASES')
		EXEC msdb.dbo.sp_delete_job @job_name=N'DB Maintain - Update Statistics - USER_DATABASES'

	if exists (select * from msdb.dbo.sysjobs where name = 'DB Maintain - Set All Standards')
		EXEC msdb.dbo.sp_delete_job @job_name=N'DB Maintain - Set All Standards'

end
GO


