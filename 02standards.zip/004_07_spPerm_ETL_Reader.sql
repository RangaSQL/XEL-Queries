USE master;
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: Feb 04, 2022
-- Description:	Assign EHR/IMO database permissions for ETL_Reader
-- =============================================
Create OR ALTER PROCEDURE dbo.spPerm_ETL_Reader_EHR
	@NoExec BIT = 0

AS
BEGIN

SET NOCOUNT ON;

DECLARE @script VARCHAR(4000) -- permission script


DECLARE ETL_Reader CURSOR FOR 
SELECT script = 'USE [' + name + ']; 
-- Create database user if necessary
IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE name = ''ETL_Reader'')
begin
	CREATE USER [ETL_Reader] FOR LOGIN [ETL_Reader] WITH DEFAULT_SCHEMA=[HPSITE]
	ALTER ROLE [db_datareader] ADD MEMBER [ETL_Reader];
end
else
	ALTER ROLE [db_datareader] ADD MEMBER [ETL_Reader];

-- Grant permissions'
FROM sys.databases
WHERE database_id > 4 
	AND (name LIKE 'EMR_%' OR name = 'EMR')
	AND is_read_only = 0 
	AND state_desc = 'ONLINE'

OPEN ETL_Reader 
FETCH NEXT FROM ETL_Reader INTO @script  
WHILE @@FETCH_STATUS = 0  
BEGIN  
	IF @NoExec = 0
		EXEC (@script)
	ELSE
		PRINT @script
	FETCH NEXT FROM ETL_Reader INTO @script 
END

CLOSE ETL_Reader
DEALLOCATE ETL_Reader

--ADD IMO DB access to ETL_Reader
--Do this one a day at 5 AM since we don't want to kick users out of DB during business time
if exists(select name from master.sys.databases where name = 'IMO')
begin
		set  @script = 'use [IMO];
		IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE name = ''ETL_Reader'')
		BEGIN
			USE [master]
			ALTER DATABASE [IMO] SET  READ_WRITE WITH NO_WAIT

			use [IMO];
			CREATE USER [ETL_Reader] FOR LOGIN [ETL_Reader];
			ALTER ROLE [db_datareader] ADD MEMBER [ETL_Reader];

			USE [master];
			ALTER DATABASE [IMO] SET  READ_ONLY WITH NO_WAIT
		END
		if IS_ROLEMEMBER (''db_datareader'',''ETL_Reader'') = 0
		begin
			USE [master]
			ALTER DATABASE [IMO] SET  READ_WRITE WITH NO_WAIT
	
			use [IMO];
				EXEC sp_addrolemember N''db_datareader'', N''ETL_Reader''

			USE [master];
			ALTER DATABASE [IMO] SET  READ_ONLY WITH NO_WAIT
		end
		'
		IF @NoExec = 0
		begin
			EXEC (@script)
			print 'Permissions granted to IMO DB for ETL_Reader'
		end
		ELSE
			PRINT @script
end

--ADD Medispan DB access to ETL_Reader
if exists(select name from master.sys.databases where name = 'Medispan')
begin
		set  @script = 'use [Medispan];
		IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE name = ''ETL_Reader'')
		BEGIN
			USE [master]
			ALTER DATABASE [Medispan] SET  READ_WRITE WITH NO_WAIT

			use [Medispan];
			CREATE USER [ETL_Reader] FOR LOGIN [ETL_Reader];
			ALTER ROLE [db_datareader] ADD MEMBER [ETL_Reader];

			USE [master];
			ALTER DATABASE [Medispan] SET  READ_ONLY WITH NO_WAIT
		END
		if IS_ROLEMEMBER (''db_datareader'',''ETL_Reader'') = 0
		begin
			USE [master]
			ALTER DATABASE [Medispan] SET  READ_WRITE WITH NO_WAIT
	
			use [Medispan];
				EXEC sp_addrolemember N''db_datareader'', N''ETL_Reader''

			USE [master];
			ALTER DATABASE [Medispan] SET  READ_ONLY WITH NO_WAIT
		end
		'
		IF @NoExec = 0
		begin
			EXEC (@script)
			print 'Permissions granted to Medispan DB for ETL_Reader'
		end
		ELSE
			PRINT @script
end
end

