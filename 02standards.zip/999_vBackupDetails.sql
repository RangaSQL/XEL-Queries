use master
go
Create or Alter View dbo.vBackupDetails
As
WITH    backupsetSummary
          AS ( SELECT   bs.database_name ,
                        bs.type bstype ,
                        MAX(backup_finish_date) MAXbackup_finish_date
               FROM     msdb.dbo.backupset bs 
			   where is_copy_only = 0
               GROUP BY bs.database_name ,
                        bs.type
             ),
        MainBigSet
          AS ( SELECT   
                        db.name ,
                        db.state_desc ,
						db.is_read_only,
						db.recovery_model_desc ,
                        bs.type ,
						bs.name BackupuApplication,
						bs.description BackupDescription, 	
						bs.user_name BackupUserName,
                        convert(decimal(10,2),bs.backup_size/1024.00/1024) backup_sizeinMB,
                                    bs.backup_start_date,
                        bs.backup_finish_date,bs.is_copy_only,
						
                                    physical_device_name,
                                    DATEDIFF(MINUTE, bs.backup_start_date, bs.backup_finish_date) AS DurationMins
                              FROM     master.sys.databases db
                        LEFT OUTER JOIN backupsetSummary bss ON bss.database_name = db.name
                        LEFT OUTER JOIN msdb.dbo.backupset bs ON bs.database_name = db.name
                                                              AND bss.bstype = bs.type
                                                              AND bss.MAXbackup_finish_date = bs.backup_finish_date
                                    JOIN msdb.dbo.backupmediafamily m ON bs.media_set_id = m.media_set_id
                                    where  db.database_id>4 
             )
SELECT
	@@SERVERNAME SQLServername,
	SERVERPROPERTY('ComputerNamePhysicalNetBIOS') ClusterNodeName,
	db.name DatabaseName,
	(SELECT CONVERT(DECIMAL(10,2),SUM(size)*8.0/1024) AS size FROM sys.master_files WHERE  db.name = DB_NAME(database_id)) AS DBSizeMB,
	db.state_desc,
	db.recovery_model_desc,
	db.is_read_only,
	ao.is_primary_replica,
	--Full
	Last_Full_Backup_start_Date =  d.backup_start_date,
	Last_Full_Backup_end_date =  d.backup_finish_date,
	Last_Full_BackupSize_MB=   d.backup_sizeinMB ,
	FullBackupDurationSeocnds =  DATEDIFF(SECOND, d.backup_start_date, d.backup_finish_date),
	Last_Full_Backup_path =  d.physical_Device_name,
	Last_Full_Backup_Application =  d.BackupuApplication,
	Last_Full_BackupDescription =  d.BackupDescription,
	Last_Full_BackupUserName = d.BackupUserName,
	Last_Full_BackupIsCopyOnly = d.Is_Copy_Only,
	--diff
	Last_Diff_Backup_start_Date = i.backup_start_date,
	Last_Diff_Backup_end_date = i.backup_finish_date,
	Last_Diff_BackupSize_MB=  i.backup_sizeinMB ,
	DiffBackupDurationSeocnds = DATEDIFF(SECOND, i.backup_start_date, i.backup_finish_date),
	Last_Diff_Backup_path =  i.physical_Device_name,
	Last_Diff_Backup_Application = i.BackupuApplication,
	Last_Diff_BackupDescription = i.BackupDescription,
	Last_Diff_BackupUserName = i.BackupUserName,
	--Log
	Last_Log_Backup_start_Date = l.backup_start_date,
	Last_Log_Backup_end_date = l.backup_finish_date,
	Last_Log_BackupSize_MB=  l.backup_sizeinMB ,
	LogBackupDurationSeocnds = DATEDIFF(SECOND, l.backup_start_date, l.backup_finish_date),
	Last_Log_Backup_path = l.physical_Device_name,
	Last_Log_Backup_Application = l.BackupuApplication,
	Last_Log_BackupDescription = l.BackupDescription,
	Last_Log_BackupUserName = l.BackupUserName
FROM
	sys.databases db 
	left join sys.dm_hadr_database_replica_states ao on db.name = db_name(ao.database_id) and is_local = 1
	left join MainBigSet d on db.name = d.name and d.type ='D'
	left join MainBigSet i on db.name = i.name and i.type ='I'
	left join MainBigSet l on db.name = l.name and l.type ='L'
where  db.database_id>4 
