use master;
go
Create or Alter View dbo.vAllJobStatus
As
SELECT  DISTINCT name AS [Job Name],
    CASE WHEN enabled=1 THEN 'Enabled'  
        ELSE 'Disabled'  
    END [Job Status],
    CASE    WHEN SJH.run_status=0 THEN 'Failed'
            WHEN SJH.run_status=1 THEN 'Succeeded'
            WHEN SJH.run_status=2 THEN 'Retry'
            WHEN SJH.run_status=3 THEN 'Cancelled'
    ELSE 'Unknown'  
    END [JobStatus],
    sjh.run_date,
    sjh.run_time
FROM    msdb.dbo.SYSJobs sj
LEFT    JOIN    msdb.dbo.SYSJobHistory sjh
ON      sj.job_id = sjh.job_id
WHERE   (
    sjh.run_date IN (
                    SELECT  MAX(sjh1.run_date)
                    FROM    msdb.dbo.SYSJobHistory sjh1
                    WHERE   sjh.job_id = sjh1.job_id
                    )
    OR sjh.run_date IS NULL
    )
AND     (
    sjh.run_time IN (
                    SELECT  MAX(sjh1.run_time)
                    FROM    msdb.dbo.SYSJobHistory sjh1
                    WHERE   sjh.job_id = sjh1.job_id
                    )
    OR  sjh.run_time IS NULL
    )
 --Last week jobs
 --select * from vAllJobStatus where msdb.dbo.agent_datetime(run_date, run_time) > getdate()-7