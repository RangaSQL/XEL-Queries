create Or Alter View dbo.vBackupRestoreStatus
As
SELECT r.session_id as SPID, command, a.text AS Query, start_time, percent_complete, dateadd(second,estimated_completion_time/1000, getdate()) as estimated_completion_time, s.host_name,s.Program_name, s.login_name
	FROM sys.dm_exec_requests r CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) a
	join sys.dm_exec_sessions s on r.session_id = s.session_id 
	WHERE r.command in ('BACKUP DATABASE','RESTORE DATABASE')



