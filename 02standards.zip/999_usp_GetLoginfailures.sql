/*
Read Error Logs for the Keyword given and number of days to go back:

Exec master.dbo.usp_GetLoginfailures @startDate = '09-11-2023', @EndDate = '09-12-2023'
*/
use master 
go
Create OR Alter procedure dbo.usp_GetLoginfailures
@StartDate Date, @EndDate Date
As
Declare @keyword varchar(100), @quote char(1)
Set @keyword = 'Login Failed'
set @quote = char(39)

if object_id('tempdb..#ErrorLogDetails') is not null
	drop table #ErrorLogDetails
if object_id('tempdb..#Errorlogs') is not null
	drop table #Errorlogs

Create Table #ErrorLogDetails(LogDate Datetime, Process varchar(256), LogMessage varchar(8000))

CREATE TABLE #Errorlogs
(
    log_number INT,
    log_date DATE,
    log_size INT
);
INSERT #Errorlogs ( log_number, log_date, log_size )
EXEC ( 'EXEC sys.sp_enumerrorlogs;' );
--select * from #Errorlogs

declare     @log_number INT,     @log_date DATE, @strsql nvarchar(200)

declare readerror cursor for select log_number,log_date from #Errorlogs order by log_date desc
open readerror
fetch next from readerror into @log_number, @log_date
while @@fetch_status = 0
begin
	if @log_date < @Startdate
		break
	set @strsql = 'sp_readerrorlog '+cast(@log_number as varchar)+', 1,'+ @quote+@keyword+@quote
	insert into #ErrorLogDetails execute(@strsql)
	fetch next from readerror into @log_number, @log_date
end
close readerror
deallocate readerror

Delete from  #ErrorLogDetails where LogDate < @StartDate 
Delete from  #ErrorLogDetails where LogDate > @EndDate

select  distinct @@Servername SQLServerName,LogDate, Process, LogMessage from #ErrorLogDetails order by Logdate Desc

