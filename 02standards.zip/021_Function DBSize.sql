USE [master]
GO

/****** Object:  UserDefinedFunction [dbo].[DBSize]    Script Date: 4/30/2020 10:25:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create or Alter Function [dbo].[DBSize](@DBName varchar(200))
RETURNS table
AS
--Example select dbo.DBSize('EMR_2173')
return(
SELECT 
			  DatabaseName = DB_NAME(database_id),
			  Floor(Round(((SUM(size) * 8)/1024),0)) DBSizeMB,
			  cast(Round((((SUM(size) * 8.0)/1024.0)/1024.0),2) as numeric(20,2)) DBSizeGB,
			  Total_Data_MB = (select Floor(Round(((SUM(size) * 8)/1024),0)) FROM sys.master_files WITH(NOWAIT) WHERE DB_NAME(database_id) = @dbname and type_desc = 'Rows' group by DB_NAME(database_id)) , 
			  Total_Log_MB = (select Floor(Round(((SUM(size) * 8)/1024),0)) FROM sys.master_files WITH(NOWAIT) WHERE DB_NAME(database_id) = @dbname and type_desc = 'log' group by DB_NAME(database_id)) ,
			  Total_Data_GB = (select Floor(Round((((SUM(size) * 8)/1024)/1024),0)) FROM sys.master_files WITH(NOWAIT) WHERE DB_NAME(database_id) = @dbname and type_desc = 'Rows' group by DB_NAME(database_id)) , 
			  Total_Log_GB = (select Floor(Round((((SUM(size) * 8)/1024)/1024),0)) FROM sys.master_files WITH(NOWAIT) WHERE DB_NAME(database_id) = @dbname and type_desc = 'log' group by DB_NAME(database_id)) 
			FROM sys.master_files WITH(NOWAIT)
		WHERE DB_NAME(database_id) = @dbname
		group by DB_NAME(database_id) 
)

/*
declare @DBName varchar(200)
set @DBName = 'Ntier_10040498'
SELECT 
			  DatabaseName = DB_NAME(database_id),
			  Floor(Round(((SUM(size) * 8)/1024),0)) DBSizeMB,
			  Floor(Round((((SUM(size) * 8)/1024)/1024),0)) DBSizeGB,
			  Total_Data_MB = (select Floor(Round(((SUM(size) * 8)/1024),0)) FROM sys.master_files WITH(NOWAIT) WHERE DB_NAME(database_id) = @dbname and type_desc = 'Rows' group by DB_NAME(database_id)) , 
			  Total_Log_MB = (select Floor(Round(((SUM(size) * 8)/1024),0)) FROM sys.master_files WITH(NOWAIT) WHERE DB_NAME(database_id) = @dbname and type_desc = 'log' group by DB_NAME(database_id)) ,
			  Total_Data_GB = (select Floor(Round((((SUM(size) * 8)/1024)/1024),0)) FROM sys.master_files WITH(NOWAIT) WHERE DB_NAME(database_id) = @dbname and type_desc = 'Rows' group by DB_NAME(database_id)) , 
			  Total_Log_GB = (select Floor(Round((((SUM(size) * 8)/1024)/1024),0)) FROM sys.master_files WITH(NOWAIT) WHERE DB_NAME(database_id) = @dbname and type_desc = 'log' group by DB_NAME(database_id)) 
			FROM sys.master_files WITH(NOWAIT)
		WHERE DB_NAME(database_id) = @dbname
		group by DB_NAME(database_id) 

*/
GO


