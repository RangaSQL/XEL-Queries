USE master;
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* =============================================
-- Author:		Ranga Narasimhan
-- Create date: Feb 16, 2022
-- Description:	This Proc stops any maintenance job by checking the name.
-- Will be called by job that runs at 6 am. 
-- Add to the list under --jobs nmes like
-- =============================================*/
CREATE or ALTER PROCEDURE dbo.spStopMaintenanceJobs 
	@NoExec BIT = 0

AS
BEGIN
SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#xp_results') IS NOT NULL
	DROP TABLE #xp_results
CREATE TABLE #xp_results (job_id UNIQUEIDENTIFIER NOT NULL,
last_run_date INT NOT NULL,
last_run_time INT NOT NULL,
next_run_date INT NOT NULL,
next_run_time INT NOT NULL,
next_run_schedule_id INT NOT NULL,
requested_to_run INT NOT NULL, -- BOOL
request_source INT NOT NULL,
request_source_id sysname COLLATE database_default NULL,
running INT NOT NULL, -- BOOL
current_step INT NOT NULL,
current_retry_attempt INT NOT NULL,
job_state INT NOT NULL)

INSERT INTO #xp_results
EXEC master..xp_sqlagent_enum_jobs 1,''

DECLARE @t TABLE (JobName VARCHAR(255), id INT IDENTITY)

INSERT INTO @t
SELECT s.name
FROM #xp_results r JOIN msdb..sysjobs s on s.job_id = r.job_id
WHERE running = 1
--jobs nmes like
AND (
	s.name LIKE ('%DBCC%')
	OR s.name LIKE ('%Consistency Check%')
	OR s.name LIKE ('%Index Reorg%')
	OR s.name LIKE ('%Update Stats%')
	OR s.name LIKE ('DB Maintain - %')
)
And s.name <> 'DB Maintain - Stop Maintenance Jobs'

--SELECT * FROM @t

DECLARE @msg VARCHAR(1000)
DECLARE @id INT, @jobname VARCHAR(255)

SELECT @id = MIN(id) FROM @t
WHILE @id IS NOT NULL
BEGIN
	SELECT @jobname = JobName FROM @t WHERE id = @id
	begin try
		if exists (SELECT sj.name
			FROM msdb.dbo.sysjobactivity AS sja
			INNER JOIN msdb.dbo.sysjobs AS sj ON sja.job_id = sj.job_id
			WHERE sja.start_execution_date IS NOT NULL
			AND sja.stop_execution_date IS NULL
			AND sj.name = @jobname)
			EXEC msdb..sp_stop_job @jobname
			set @msg = @jobname +' - Job stopped...'
			print @msg
	end try
	begin catch
		print Error_message()
	end catch
	SELECT @id = min(id) FROM @t WHERE id > @id
END
End