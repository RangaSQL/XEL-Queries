Create Or Alter View dbo.vDriveSpace
As
WITH core AS ( 
    SELECT DISTINCT SERVERPROPERTY('ComputerNamePhysicalNetBIOS') NodeName, @@servername SQLName,
        s.volume_mount_point [Drive]
        ,cast(Round((((s.total_bytes/1024.0)/1024.0)/1024),0) as int) TotalSizeInGB
		,cast(Round((((s.available_bytes/1024.0)/1024.0)/1024),0) as int) AvailableSizInGB

    FROM 
        sys.master_files f
        CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.[file_id]) s
		
)
select NodeName, SQLName,Drive, TotalSizeInGB, AvailableSizInGB,(TotalSizeInGB - AvailableSizInGB) As UsedSizeInGB 
from core

