
if not exists(select * from sys.configurations where name = 'Database Mail XPs' and value = 1)
begin
	EXEC msdb.dbo.sp_configure
	  @configname = 'show advanced options',
	  @configvalue = 1;

	RECONFIGURE;
	EXEC msdb.dbo.sp_configure
	  @configname = 'Database Mail XPs',
	  @configvalue = 1;
	RECONFIGURE;
end


Declare  @Email varchar(50)
set @Email = @@servername+'@veradigm.com'

if not exists (select * from msdb.dbo.sysmail_profile where name = 'admin')
begin


	EXECUTE msdb.dbo.sysmail_add_profile_sp
	  @profile_name = 'Admin',
	  @description  = 'Profile for sending Health Check Report Emails';

	EXEC msdb.dbo.sysmail_add_account_sp
	  @account_name = 'Admin',
	  @email_address = @Email, --'ProSentryOne@veradigm.com',
	  @display_name = 'ProSuitesHealthCheck-Azure',
	  @replyto_address = '',
	  @description = 'Profile for sending Health Check Report Emails',
	  @mailserver_name = 'smtp.sendgrid.net',
	  @mailserver_type = 'SMTP',
	  @port = '25',
	  @username = 'apikey',
	  @password = 'Ask Dale',
	  @use_default_credentials = 0,
	  @enable_ssl = 0;

	EXEC msdb.dbo.sysmail_add_profileaccount_sp
	  @profile_name = 'Admin',
	  @account_name = 'Admin',
	  @sequence_number = 1;

	EXEC msdb.dbo.sysmail_add_principalprofile_sp
	  @profile_name = 'Admin',
	  @principal_name = 'guest',
	  @is_default = 1;
end
