Create or Alter view dbo.vDBSize
As
select s.DatabaseName, sum(s.DBSizeGB) TotalSize_GB, sum(s.Total_Data_GB) TotalSize_Data_GB , sum(s.Total_Log_GB) TotalSize_Log_GB, sum(s.DBSizeMB) TotalSize_MB, sum(s.Total_Data_MB) TotalSize_Data_MB , sum(s.Total_Log_MB) TotalSize_Log_MB
from sys.databases d cross apply dbo.DBSize(name) s
Group by s.DatabaseName
go


