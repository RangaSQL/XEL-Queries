USE [master]
GO
/****** Object:  StoredProcedure [dbo].[dba_GenerateDBRestore_AtSource_Native]    Script Date: 01/14/2008 11:06:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

if exists(select * from sys.procedures where name = 'dba_GenerateDBRestore_AtSource_Native_Output')
	drop procedure dbo.dba_GenerateDBRestore_AtSource_Native_Output
go
/*
Author:		Ranga Narasimhan
Create date: 01-01-2018
Description: Generates Restore command from the latest backup location
Exec Example: exec dbo.dba_GenerateDBRestore_AtSource_Native_Output 'DBName'
*/
create PROC [dbo].[dba_GenerateDBRestore_AtSource_Native_Output] ( @DBName varchar(255))
as
begin
declare  @backUpfile varchar(1024)
declare  @backUpfile1 varchar(1024)
Declare  @insString varchar(1024),@OrgDBname varchar(255)

--dba_GenerateDBRestore_AtSource_Native Taxan

SET NOCOUNT  ON

create table #tb_filelist 
	(
	 FileId			int,
	 LogicalName 	nvarchar(255),
	 PhysicalName  	nvarchar(255),  
	)


create table #tb_final
	( row_count   int identity,
	  stringData varchar(1024)
	)

-- Table to Hold the Header Info

Create table #Header
	(
	FileNumber 		varchar(24) ,
	Guid 			varchar(1024) ,                                                                                                 
	BackupName 		varchar(1024) ,
	BackupDescription 	varchar(1024) ,
	BackupType 		varchar(24) ,
	ExpirationDate 		varchar(124) ,
	Compressed 		varchar(24) ,
	Position 		varchar(24) ,
	DeviceType 		varchar(1024) ,
	UserName 		varchar(45) ,
	ServerName 		varchar(124) ,
	DatabaseName 		varchar(124) ,
	DatabaseVersion 	varchar(25) ,
	DatabaseCreationDate 	varchar(124) ,
	BackupSize 		varchar(124) ,
	FirstLsn 		varchar(124) ,
	LastLsn 		varchar(124) ,
	CheckpointLsn 		varchar(124) ,
	DifferentialBaseLsn 	varchar(124) ,
	BackupStartDate 	varchar(124) ,
	BackupFinishDate 	varchar(124) ,
	SortOrder 		varchar(124) ,
	CodePage 		varchar(124) ,
	CompatibilityLevel 	varchar(124) ,
	SoftwareVendorId 	varchar(124) ,
	SoftwareVersionMajor 	varchar(124) ,
	SoftwareVersionMinor 	varchar(124) ,
	SoftwareVersionBuild 	varchar(124) ,
	MachineName 		varchar(124) ,
	BindingId  		varchar(124) ,
	RecoveryForkId 		varchar(124) ,
	sEncryption 		varchar(124)
)     


select BMF.physical_device_name 
into #t_backupset
from msdb.dbo.backupset  BS , msdb.dbo.backupmediaset BMS , msdb.dbo.backupmediafamily BMF
where
 BS.media_set_id = BMS.media_set_id and
 BMF.media_set_id = BMS.media_set_id and
   BS.database_name = @DBName  and
   BS.type = 'D' and
   BS.backup_finish_date = (select max(backup_finish_date) from msdb.dbo.backupset where database_name = @DBName
			    and type = 'D' )

                     

set @backUpfile = (select top 1 * from #t_backupset)
/*
insert into #Header
EXEC master.dbo.xp_restore_headeronly @filename =  @backUpfile
*/
set @OrgDBname = @DBName

insert into #tb_filelist 
select fileid, name, filename from master..sysaltfiles where dbid = db_id(@DBName)   

set @insString = 'restore database '+ @DBName  +' from '
insert into #tb_final (stringData) values( @insString  )


update #tb_filelist
set 
PhysicalName = REPLACE ( PhysicalName , @OrgDBname , @DBName )

update #tb_filelist
set 
PhysicalName = REPLACE ( PhysicalName , lower(@OrgDBname) , @DBName )

-- substring (PhysicalName, 1,3)+ 'mssql\data\' +
/*
update #tb_filelist
set 
PhysicalName =  substring (PhysicalName, 1,3)+ 'mssql\data\' +	reverse(substring (reverse(PhysicalName), 1,PATINDEX ( '%\%' , REVERSE(PhysicalName) ) -1) )
*/

/*
update #tb_filelist
set PhysicalName = substring (PhysicalName, 1,3)+ 'mssql\data\'
*/

/* -----------------------------------------------------
    Logic for getting Multiple Backup file names
   ----------------------------------------------------- */

DECLARE bkpfiles_cursor CURSOR FOR 
   SELECT *
   FROM #t_backupset

   OPEN bkpfiles_cursor

   FETCH NEXT FROM bkpfiles_cursor INTO @backUpfile

   
   WHILE @@FETCH_STATUS = 0
   BEGIN
	  set @backUpfile1 = @backUpfile
	  set @insString  = 'disk = '  + ''''  + @backUpfile  + '''' + ','
	  insert into #tb_final (stringData) values( @insString  )
	  FETCH NEXT FROM bkpfiles_cursor INTO @backUpfile
			
   END

   CLOSE bkpfiles_cursor
   DEALLOCATE bkpfiles_cursor

-- to remove the "," from the last backup file.
delete from #tb_final where row_count =( select max(row_count) from #tb_final)
set @insString  = 'disk = '  + ''''  + @backUpfile  + '''' 
insert into #tb_final (stringData) values( @insString  )

insert into #tb_final (stringData)
select ' WITH '	


insert into #tb_final (stringData)
select  'MOVE    ' + ''''  + LogicalName + '''   To  ''' + PhysicalName + ''','
	from #tb_filelist



-- print @insString

-- Get rid of the , from the last row
update #tb_final
set 
     stringData = substring(stringData,1, len(stringData)-1)
where
     row_count = (select max(row_count) from #tb_final)

set @insString  = ', '+' norecovery' 
insert into #tb_final (stringData) values( @insString  )

select @DBName,stringData from #tb_final order by row_count

-- select LogicalName, PhysicalName from #tb_filelist


-- select LogicalName, PhysicalName from #tb_filelist


drop table #tb_filelist
drop table #tb_final
drop table  #Header
drop table #t_backupset
end 




