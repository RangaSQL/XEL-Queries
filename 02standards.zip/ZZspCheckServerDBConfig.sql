CREATE OR ALTER PROCEDURE [dbo].[spCheckServerDBConfig]
AS
/*
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: Jan 01a, 2024
-- Description:	This SP will will check for all Server/DB config settings. Can be run anytime to verify server config
-- =============================================

*/
set nocount on
 Declare @SQLVersion varchar(100),@CpuCount int,  @OsMemoryGB int, @SQLMaxMemory sql_variant, @ctp sql_variant, @dop sql_variant, @tempfilesCount smallint, @OAHW sql_variant, @BUComp sql_variant

--select @SQLVersion
--select charindex('2008', @SQLVersion, 1) 

--If (charindex('2008', @SQLVersion, 1) > 1)
--	SELECT  @Osmemory =  ((physical_memory_in_bytes/1024)/1024) FROM sys.dm_os_sys_info

--If (charindex('2014', @SQLVersion, 1) > 1)
--	SELECT  @Osmemory = (physical_memory_kb/1024) FROM sys.dm_os_sys_info

Select @SQLVersion = LEFT(@@VERSION,PATINDEX('%(X64)%',@@VERSION)+4)
select @CpuCount = cpu_count FROM sys.dm_os_sys_info
select @tempfilesCount = count(*) from master.sys.sysaltfiles where dbid = 2
select @ctp = value_in_use from sys.configurations where name = 'cost threshold for parallelism'
select @dop = value_in_use from sys.configurations where name = 'max degree of parallelism'
select @OAHW = value_in_use from sys.configurations where name = 'optimize for ad hoc workloads'
select @BUComp = value_in_use from sys.configurations where name = 'backup compression default'
SELECT @SQLMaxMemory = CAST(ROUND(CONVERT(INT,value_in_use)/1024.0,0) AS INT) FROM sys.configurations where name = 'max server memory (MB)'
SELECT @OsMemoryGB = CAST(ROUND(((physical_memory_kb/1024)/1024.0),0) AS INT) FROM sys.dm_os_sys_info 



--Data/Log/Backup folders TCP setting
declare @rc int 
,@instdir nvarchar(100) 
,@datadir nvarchar(100) 
,@logdir nvarchar(100) 
,@backupdir nvarchar(100) 
,@TcpPort nvarchar(100) 
,@MSDTS nvarchar(100)
,@MSDTS_Acct nvarchar(100)
,@MSDTS_Start int
exec @rc = master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'DefaultData', @datadir output, 'no_output'  
exec @rc = master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'DefaultLog', @logdir output, 'no_output'  
exec @rc = master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'BackupDirectory', @backupdir output, 'no_output'  
exec @rc = master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\Setup',N'SQLPath',@instdir output, 'no_output'
exec @rc = master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer\SuperSocketNetLib\TCP\IPAll',N'TcpPort', @TcpPort output, 'no_output'  
exec @rc = master.dbo.xp_regread N'HKEY_LOCAL_MACHINE',N'System\CurrentControlSet\Services\MsDtsServer140',N'DisplayName', @MSDTS output, 'no_output'
exec @rc = master.dbo.xp_regread N'HKEY_LOCAL_MACHINE',N'System\CurrentControlSet\Services\MsDtsServer140',N'ObjectName', @MSDTS_Acct output, 'no_output'
exec @rc = master.dbo.xp_regread N'HKEY_LOCAL_MACHINE',N'System\CurrentControlSet\Services\MsDtsServer140',N'Start', @MSDTS_Start output, 'no_output'
exec @rc = master.dbo.xp_regread N'HKEY_LOCAL_MACHINE',N'System\CurrentControlSet\Services\MsDtsServer150',N'DisplayName', @MSDTS output, 'no_output'
exec @rc = master.dbo.xp_regread N'HKEY_LOCAL_MACHINE',N'System\CurrentControlSet\Services\MsDtsServer150',N'ObjectName', @MSDTS_Acct output, 'no_output'
exec @rc = master.dbo.xp_regread N'HKEY_LOCAL_MACHINE',N'System\CurrentControlSet\Services\MsDtsServer150',N'Start', @MSDTS_Start output, 'no_output'
exec @rc = master.dbo.xp_regread N'HKEY_LOCAL_MACHINE',N'System\CurrentControlSet\Services\MsDtsServer160',N'DisplayName', @MSDTS output, 'no_output'
exec @rc = master.dbo.xp_regread N'HKEY_LOCAL_MACHINE',N'System\CurrentControlSet\Services\MsDtsServer160',N'ObjectName', @MSDTS_Acct output, 'no_output'
exec @rc = master.dbo.xp_regread N'HKEY_LOCAL_MACHINE',N'System\CurrentControlSet\Services\MsDtsServer160',N'Start', @MSDTS_Start output, 'no_output'
SELECT CASE @MSDTS 
WHEN 'SQL Server Integration Services 14.0' THEN '2016'
WHEN 'SQL Server Integration Services 15.0' THEN '2019'
WHEN 'SQL Server Integration Services 16.0' THEN '2022'
END [SSIS Version]
, CASE @MSDTS_Start
WHEN 0 THEN 'Other'
WHEN 1 THEN 'Other'
WHEN 2 THEN 'Automatic'
WHEN 3 THEN 'Manual'
WHEN 4 THEN 'Disabled'
END AS [Startup Type]
, @MSDTS_Acct [Service Account]

select @@Servername SQLInstance, @datadir [Data Directory], @logdir [Log Directory], @backupdir [Backup Directory], @instdir AS InstallationDirectory, @TcpPort [TCP Port] 

Select servicename, startup_type_desc, service_account,is_clustered, instant_file_initialization_enabled from sys.dm_server_services
Select 
	SERVERPROPERTY('ComputerNamePhysicalNetBIOS') ClusterNodeName
	,@@Servername SQLInstance
	,@SQLVersion SQLVersion
	,@CpuCount CPUCount
	,@tempfilesCount Tempfilecount
	,@OsMemoryGB OsMemoryGB
	,@SQLMaxMemory SQLMaxMemoryGB
	,CAST((CAST(@SQLMaxMemory AS NUMERIC(10,4)))/(CAST(@OsMemoryGB AS NUMERIC(10,4))) AS NUMERIC(4,2))*100 [Max Memory %]
	,@ctp CostThresholdForParallelism
	,@dop MAX_DOP
	,CASE @BUComp WHEN 1 THEN 'On' WHEN 2 THEN 'Off' END AS [B/U Compression]
	,@OAHW optimize_for_ad_hoc_workloads


--TempDB Files
select @@Servername SQLInstance, Physical_name, (size*8/1024) SizeMB,  (growth*8/1024) GrowthMB from master.sys.master_files where db_name(database_id)='tempdb'

--Disk space
Select * from dbo.vdrivespace


select name, suser_sid('sa') sa_sid,state_desc,is_read_only, owner_sid, recovery_model_desc, page_verify_option_desc, is_auto_create_stats_on, is_auto_update_stats_on from master.sys.databases

Select 'System Databases' DatabaseType
select name, physical_name, type_desc, state_desc,max_size,(8*growth/1024)growth_MB, is_percent_growth,is_read_only from sys.master_files
where database_id in(1,3,4) --no tempdb
Select 'user Databases - Data' DatabaseFileType
select db_name(database_id) DBName,name, physical_name, type_desc, state_desc,max_size,(8*growth/1024)growth_MB, is_percent_growth,is_read_only from sys.master_files
where database_id >4 and type_desc ='rows'
Select 'user Databases - Log' DatabaseFileType
select db_name(database_id) DBName,name, physical_name, type_desc, state_desc,max_size,(8*growth/1024)growth_MB, is_percent_growth,is_read_only from sys.master_files
where database_id >4 and type_desc ='log'

IF exists(Select * from sys.master_files where physical_name like 'C%' and database_id > 4)
begin
	Select 'Move DB Data Files From C - Move-DbaDbFile -SqlInstance SQLServer -Database DBName  -FileType Data -FileDestination M:\Data' ActionNeeded
	Select 'Move DB Log Files From C - Move-DbaDbFile -SqlInstance SQLServer -Database DBName  -FileType Log -FileDestination L:\Log' ActionNeeded
end
else
	Select 'NO User DB Files on C:' 'No Action Needed'


DBCC TRACESTATUS(-1);

-- Server File Data
SELECT @@SERVERNAME [Instance],
	name [Server Audit Name], 
	(SELECT DISTINCT p.name FROM sys.server_principals p INNER JOIN sys.server_file_audits a ON a.principal_id = p.principal_id) [Audit Owner],
	CASE is_state_enabled WHEN 1 THEN 'Yes' WHEN 0 THEN 'No' END AS [Enabled?], 
	on_failure_desc [On Failure], 
	create_date [Created], 
	modify_date [Modified], 
	type_desc [Audit Type], 
	log_file_path [File Path], 
	log_file_name [File Name],
	max_file_size [Max File Size (MB)], 
	max_rollover_files [Rollover Files], 
	max_files [Max Files], 
	CASE reserve_disk_space WHEN 1 THEN 'Yes' WHEN 0 THEN 'No' END AS [Reserve Disk Space?]
FROM sys.server_file_audits


-- Database Audit Data
IF OBJECT_ID('tempdb..#AuditSpec') IS NOT NULL
	DROP TABLE #AuditSpec

CREATE TABLE #AuditSpec
(
	InstName					varchar(128),
	DBName						varchar(128),
	[Name]						sysname,
	database_specification_id	int,
	create_date					datetime,
	modify_date					datetime,
	is_state_enabled			bit,
	audit_GUID					binary
)

EXEC sp_MSForEachDB
'USE [?];
INSERT INTO #AuditSpec
SELECT @@SERVERNAME, DB_NAME(), [Name], database_specification_id, create_date, modify_date, is_state_enabled, audit_GUID
FROM sys.database_audit_specifications
'
SELECT InstName [Instance]
	, [Name] [Database Audit Specification]
	, DBName [Database]
	, CASE is_state_enabled
	WHEN 1 THEN 'Yes'
	WHEN 0 THEN 'No'
	END AS [Enabled?]
	, create_date [Created]
	, modify_date [Modified]
FROM #AuditSpec
GO
