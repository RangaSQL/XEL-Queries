CREATE or Alter PROC dbo.[usp_QueryToHtmlTable]
(
    @Query    NVARCHAR(MAX)                 --A query to turn into HTML format. It should not include an ORDER BY clause.
    ,@OrderBy NVARCHAR(MAX) = NULL          --An optional ORDER BY clause. It should contain the words 'ORDER BY'.
    ,@HTML    NVARCHAR(MAX) = NULL OUTPUT   --The HTML output of the procedure.
)
AS
/*
declare @strhtml varchar(max)
Exec dbo.[usp_QueryToHtmlTable]
@query = 'select * from ProsuiteInfo.dbo.StageLoginFailureReport'
,@orderBy = ' Failurecount '
,@html = @strhtml  output
*/
BEGIN
    SET NOCOUNT ON;

    IF @OrderBy IS NULL BEGIN
SET @OrderBy = '';
    END;

    SET @OrderBy = REPLACE(@OrderBy, '''', '''''');

    DECLARE @realQuery NVARCHAR(MAX) = N'
    DECLARE @headerRow nvarchar(MAX);
    DECLARE @cols nvarchar(MAX);    

    SELECT * INTO #dynSql FROM (' + @Query
                                       + N') sub;

    SELECT @cols = COALESCE(@cols + '', '''''''', '', '''') + ''['' + name + ''] AS ''''td''''''
    FROM tempdb.sys.columns 
    WHERE object_id = object_id(''tempdb..#dynSql'')
    ORDER BY column_id;

    SET @cols = ''SET @HTML = CAST(( SELECT '' + @cols + '' FROM #dynSql ' + @OrderBy
                                       + N' FOR XML PATH(''''tr''''), ELEMENTS XSINIL) AS nvarchar(max))''    

    EXEC sys.sp_executesql @cols, N''@HTML nvarchar(MAX) OUTPUT'', @HTML=@HTML OUTPUT

    SELECT @headerRow = COALESCE(@headerRow + '''', '''') + ''<th>'' + name + ''</th>'' 
    FROM tempdb.sys.columns 
    WHERE object_id = object_id(''tempdb..#dynSql'')
    ORDER BY column_id;

    SET @headerRow = ''<tr>'' + @headerRow + ''</tr>'';

    SET @HTML = ''<table border="1">'' + @headerRow + @HTML + ''</table>'';    
    ';

    EXEC sys.sp_executesql @realQuery
                           ,N'@HTML nvarchar(MAX) OUTPUT'
                           ,@HTML = @HTML OUTPUT;
END;