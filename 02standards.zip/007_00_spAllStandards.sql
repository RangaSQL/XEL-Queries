USE master;
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Ranga Narasimhan
-- Create date: 02222022
-- Description:	Main Proc that call other Standardization SPs. This SP will be used in the single Job to manage standards in all SQL instances.
-- =============================================
CREATE or ALTER PROCEDURE dbo.spAllstandards 
AS
BEGIN
SET NOCOUNT ON;


--#1 Change all database owner to SA
Begin Try
	Exec dbo.spChangeDatabaseOwnerToSA
	print 'spChangeDatabaseOwnerToSA - exec success'
end Try
Begin catch
	raiserror ('Stored Proc: spChangeDatabaseOwnerToSA Failed',16,0)
	print ERROR_MESSAGE()
end catch

--#2 Change all Job owner to SA
Begin Try
	Exec dbo.spChangeJobOwnerToSA
	print 'spChangeJobOwnerToSA - exec success'
end Try
Begin catch
	raiserror ('Stored Proc: spChangeJobOwnerToSA Failed',16,0)
	print ERROR_MESSAGE()
end catch

--#3 Change DB to checksum
Begin Try
	Exec dbo.spChangePageVerifyToCheckSum
	print 'spChangePageVerifyToCheckSum - exec success'
end Try
Begin catch
	raiserror ('Stored Proc: spChangePageVerifyToCheckSum Failed',16,0)
	print ERROR_MESSAGE()
end catch

--#4 Change DB file autogrow
Begin Try
	Exec dbo.spAlterDBAutoGrowSetting
	print 'spAlterDBAutoGrowSetting - exec success'
end Try
Begin catch
	raiserror ('Stored Proc: spAlterDBAutoGrowSetting Failed',16,0)
	print ERROR_MESSAGE()
end catch

--#5 dbo.spRemoveOtherMaintenanceJobs
Begin Try
	Exec dbo.spRemoveOtherMaintenanceJobs
	print 'dbo.spRemoveOtherMaintenanceJobs - exec success'
end Try
Begin catch
	raiserror ('Stored Proc: dbo.spRemoveOtherMaintenanceJobs Failed',16,0)
	print ERROR_MESSAGE()
end catch

--#6 dbo.spRemoveOtherMaintenanceJobs
Begin Try
	Exec dbo.spRemoveMaintenancePlan
	print 'dbo.spRemoveMaintenancePlan - exec success'
end Try
Begin catch
	raiserror ('Stored Proc: dbo.spRemoveMaintenancePlan Failed',16,0)
	print ERROR_MESSAGE()
end catch

--#7 dbo.spRemoveMaintenanceJobsFromRPTServers
Begin Try
	Exec dbo.spRemoveMaintenanceJobsFromRPTServers
	print 'dbo.spRemoveMaintenanceJobsFromRPTServers - exec success'
end Try
Begin catch
	raiserror ('Stored Proc: dbo.spRemoveMaintenanceJobsFromRPTServers Failed',16,0)
	print ERROR_MESSAGE()
end catch

Print 'All Standards - exec success!!'

END


