--Set SQL Min and MAx Memory 
set nocount on
Declare @OsMemoryGB numeric, @SQLMaxMemory sql_variant, @SQLMinMemory sql_variant, @SQLMemoryPercent smallint, @strsql nvarchar(300)
Declare @SQLMaxMemoryNew sql_variant, @SQLMinMemoryNew sql_variant, @SQLMemoryPercentNew smallint
SELECT @SQLMaxMemory = CAST(ROUND(CONVERT(INT,value_in_use)/1024.0,0) AS INT) FROM sys.configurations where name = 'max server memory (MB)'
SELECT @SQLMinMemory = CAST(ROUND(CONVERT(INT,value_in_use)/1024.0,0) AS INT) FROM sys.configurations where name = 'min server memory (MB)'
SELECT @OsMemoryGB = CAST(ROUND(((physical_memory_kb/1024)/1024.0),0) AS INT) FROM sys.dm_os_sys_info 
if @SQLMaxMemory = 2097152
	set @SQLMemoryPercent = 100
else
	select @SQLMemoryPercent = cast((Round(((cast (@SQLMaxMemory as numeric(5,2))/@OsMemoryGB) *100.0),0)) as int)

Declare @MemoryStandards Table(OSRamLow int,OSRamHigh int, PercentForSQL Numeric(5,2)) 
Insert into @MemoryStandards(OSRamLow,OSRamHigh, PercentForSQL) Values
(0,4,50.0),
(4,8,60.0),
(8,12,65.0),
(12,24,	70.0),
(24,48,75.0),
(48,64,80.0),
(64,128,83.0),
(128,256,85.0),
(256,99999,87.0);

select @SQLMemoryPercentNew = PercentForSQL from @MemoryStandards where (@OsMemoryGB >= OSRamLow) and (@OsMemoryGB < OSRamHigh)
Select @SQLMaxMemoryNew = cast(((@OsMemoryGB)*(@SQLMemoryPercentNew/100.00)) as smallint)  
Select @SQLMinMemoryNew = cast((@SQLMaxMemoryNew) as smallint)/2 --from @MemoryStandards where (@OsMemoryGB >= OSRamLow ) and (@OsMemoryGB < OSRamHigh   ) 
--For ATP
If @@SERVERNAME like '%ATP%' -- it is 75%
BEGIN
	set @SQLMemoryPercentNew = 75
	Select @SQLMaxMemoryNew = cast((((@OsMemoryGB)*(@SQLMemoryPercentNew))/100) as smallint) --from @MemoryStandards where (@OsMemoryGB > OSRamLow) and (@OsMemoryGB <= OSRamHigh) 
	Select @SQLMinMemoryNew = cast((@SQLMaxMemoryNew) as smallint)/2 --from @MemoryStandards where (@OsMemoryGB > OSRamLow) and (@OsMemoryGB <= OSRamHigh) 
end
--select @SQLMinMemoryNew, @SQLMaxMemoryNew
select * from @MemoryStandards	
select @OsMemoryGB OsMemoryGB, @SQLMinMemory SQLMinMemory, @SQLMaxMemory SQLMaxMemory,@SQLMemoryPercent SQLMemoryPercent
select @OsMemoryGB OsMemoryGB, @SQLMinMemoryNew SQLMinMemoryNew, @SQLMaxMemoryNew SQLMaxMemoryNew,@SQLMemoryPercentNew SQLMemoryPercentNew


if @SQLMaxMemoryNew <> @SQLMaxMemory
begin
	set @strsql ='EXEC sys.sp_configure N'''+'show advanced options'', N''1''  RECONFIGURE WITH OVERRIDE;
	EXEC sys.sp_configure N'''+'max server memory (MB)'', N'''+cast((cast(@SQLMaxMemoryNew as int)*1024) as varchar)+''';
	RECONFIGURE WITH OVERRIDE;
	EXEC sys.sp_configure N'''+'show advanced options'', N''0''  RECONFIGURE WITH OVERRIDE;'
	exec sp_executesql @strsql
end
--print @strsql

if @SQLMinMemoryNew <> @SQLMinMemory
begin
	set @strsql ='EXEC sys.sp_configure N'''+'show advanced options'', N''1''  RECONFIGURE WITH OVERRIDE;
	EXEC sys.sp_configure N'''+'min server memory (MB)'', N'''+cast((cast(@SQLMinMemoryNew as int)*1024) as varchar)+''';
	RECONFIGURE WITH OVERRIDE;
	EXEC sys.sp_configure N'''+'show advanced options'', N''0''  RECONFIGURE WITH OVERRIDE;'
	exec sp_executesql @strsql
end
--print @strsql

